import importlib.util,json,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('audit','scripts/clickbench-audit.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
r=Path('reports/audit-20260913-validated')
command=['/usr/bin/time','-v','-o',str(r/'crosscheck-gnu-time.txt'),sys.executable,'-c','x=bytearray(64*1024*1024); sum(i*i for i in range(2000000))']
result=audit.measure(command,r/'crosscheck',10)
f=dict(line.strip().split(': ',1) for line in (r/'crosscheck-gnu-time.txt').read_text().splitlines() if ': ' in line)
result['gnu_rss_bytes']=int(f['Maximum resident set size (kbytes)'])*1024
result['gnu_cpu_s']=float(f['User time (seconds)'])+float(f['System time (seconds)'])
result['rss_match']=result['gnu_rss_bytes']==result['peak_rss_bytes']
result['cpu_within_rounding']=abs(result['cpu_s']-result['gnu_cpu_s'])<.025
assert result['rss_match'] and result['cpu_within_rounding']
(r/'crosscheck.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
