# ClickBench measurement audit

All 43 SQL queries are attempted on DuckDB native, rudb native, DuckDB Parquet, and rudb Parquet. Five hot repetitions are required for a complete row. A failed repetition invalidates that query; successful fragments are never averaged into a result.

First execution is not disk-cold: the page cache is not flushed. Each repetition uses a fresh process. Query seconds are the CLI timer, including result rendering; wall and CPU seconds and peak RSS cover the whole child process. CPU and RSS come from wait4 for that child. RSS is the maximum resident set, not allocated bytes or an incremental memory delta. Both native rows open a loaded single-file database. Both Parquet rows query the same source file with native mirroring disabled; metadata-only paths remain available. These are sample results, not official ClickBench scores.

| Size | Engine | Load wall (s) | Load CPU (s) | Load peak RSS (MiB) | Native bytes |
| --- | --- | ---: | ---: | ---: | ---: |
| 1k | duckdb-native | 0.068958 | 0.094650 | 67.91 | 1060864 |
| 1k | rudb-native | 0.135214 | 0.122267 | 38.19 | 1876635 |
| 10k | duckdb-native | 0.134636 | 0.135694 | 58.55 | 4468736 |
| 10k | rudb-native | 0.429287 | 0.484072 | 71.53 | 7732602 |
| 1m | duckdb-native | 5.045664 | 14.144980 | 1297.64 | 447492096 |
| 1m | rudb-native | 2.966615 | 10.867580 | 1479.52 | 246601478 |
| 10m | duckdb-native | 63.946198 | 97.941519 | 2287.05 | 2369007616 |
| 10m | rudb-native | 58.089238 | 89.541360 | 1405.91 | 1468163998 |

| Size | Engine | Complete / 43 | Query median sum (s) | Process wall median sum (s) | CPU median sum (s) | Peak RSS (MiB) |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 1k | duckdb-native | 43 | 0.069000 | 0.887351 | 0.893117 | 35.72 |
| 1k | rudb-native | 43 | 0.045025 | 0.290102 | 0.247601 | 12.84 |
| 1k | duckdb-parquet | 43 | 0.081000 | 0.896962 | 0.904036 | 33.03 |
| 1k | rudb-parquet | 43 | 0.052428 | 0.281359 | 0.240092 | 11.55 |
| 10k | duckdb-native | 43 | 0.087000 | 0.929050 | 0.951053 | 37.66 |
| 10k | rudb-native | 43 | 0.054440 | 0.328053 | 0.283646 | 13.91 |
| 10k | duckdb-parquet | 43 | 0.111000 | 0.950805 | 0.968610 | 38.62 |
| 10k | rudb-parquet | 43 | 0.084959 | 0.319389 | 0.275507 | 13.95 |
| 1m | duckdb-native | 43 | 0.863000 | 1.917000 | 4.644198 | 269.86 |
| 1m | rudb-native | 43 | 0.269960 | 0.615288 | 1.113989 | 81.72 |
| 1m | duckdb-parquet | 43 | 1.197000 | 2.238828 | 5.584672 | 412.44 |
| 1m | rudb-parquet | 43 | 1.181712 | 1.532004 | 4.606550 | 332.06 |
| 10m | duckdb-native | 43 | 7.042000 | 9.437274 | 30.103371 | 1155.27 |
| 10m | rudb-native | 43 | 1.197205 | 1.853588 | 5.124559 | 282.28 |
| 10m | duckdb-parquet | 43 | 10.282000 | 12.546150 | 39.020061 | 988.05 |
| 10m | rudb-parquet | 43 | 8.965274 | 9.620914 | 34.289948 | 795.08 |

Time totals cover complete queries only; peak RSS includes every measured attempt, including failures. Compare engines only on the same completed query set. Raw JSONL retains every repetition, exit status, CPU components, I/O, page faults, context switches, command, and output paths.

| Size | Query | Answer check |
| --- | --- | --- |
| 1k | q1 | original match |
| 1k | q2 | original match |
| 1k | q3 | original match |
| 1k | q4 | original match |
| 1k | q5 | original match |
| 1k | q6 | original match |
| 1k | q7 | original match |
| 1k | q8 | original match |
| 1k | q9 | same rows; different order |
| 1k | q10 | same rows; different order |
| 1k | q11 | same rows; different order |
| 1k | q12 | same rows; different order |
| 1k | q13 | original selections differ; deterministic retest match |
| 1k | q14 | original selections differ; deterministic retest match |
| 1k | q15 | original selections differ; deterministic retest match |
| 1k | q16 | original selections differ; deterministic retest match |
| 1k | q17 | original selections differ; deterministic retest match |
| 1k | q18 | original selections differ; deterministic retest match |
| 1k | q19 | original selections differ; deterministic retest match |
| 1k | q20 | original match |
| 1k | q21 | original match |
| 1k | q22 | original match |
| 1k | q23 | original match |
| 1k | q24 | original match |
| 1k | q25 | original match |
| 1k | q26 | original match |
| 1k | q27 | original match |
| 1k | q28 | original match |
| 1k | q29 | original match |
| 1k | q30 | original match |
| 1k | q31 | original selections differ; deterministic retest match |
| 1k | q32 | original selections differ; deterministic retest match |
| 1k | q33 | original selections differ; deterministic retest match |
| 1k | q34 | original selections differ; deterministic retest match |
| 1k | q35 | original selections differ; deterministic retest match |
| 1k | q36 | original selections differ; deterministic retest match |
| 1k | q37 | same rows; different order |
| 1k | q38 | same rows; different order |
| 1k | q39 | original match |
| 1k | q40 | original match |
| 1k | q41 | original match |
| 1k | q42 | original match |
| 1k | q43 | original match |
| 10k | q1 | original match |
| 10k | q2 | original match |
| 10k | q3 | original match |
| 10k | q4 | original match |
| 10k | q5 | original match |
| 10k | q6 | original match |
| 10k | q7 | original match |
| 10k | q8 | same rows; different order |
| 10k | q9 | original match |
| 10k | q10 | original match |
| 10k | q11 | original selections differ; deterministic retest match |
| 10k | q12 | original selections differ; deterministic retest match |
| 10k | q13 | original selections differ; deterministic retest match |
| 10k | q14 | original selections differ; deterministic retest match |
| 10k | q15 | original selections differ; deterministic retest match |
| 10k | q16 | original selections differ; deterministic retest match |
| 10k | q17 | original selections differ; deterministic retest match |
| 10k | q18 | original selections differ; deterministic retest match |
| 10k | q19 | original selections differ; deterministic retest match |
| 10k | q20 | original match |
| 10k | q21 | original match |
| 10k | q22 | original match |
| 10k | q23 | original match |
| 10k | q24 | original match |
| 10k | q25 | original match |
| 10k | q26 | original match |
| 10k | q27 | original match |
| 10k | q28 | original match |
| 10k | q29 | original match |
| 10k | q30 | original match |
| 10k | q31 | original selections differ; deterministic retest match |
| 10k | q32 | original selections differ; deterministic retest match |
| 10k | q33 | original selections differ; deterministic retest match |
| 10k | q34 | same rows; different order |
| 10k | q35 | same rows; different order |
| 10k | q36 | original selections differ; deterministic retest match |
| 10k | q37 | original selections differ; deterministic retest match |
| 10k | q38 | original selections differ; deterministic retest match |
| 10k | q39 | original match |
| 10k | q40 | original match |
| 10k | q41 | original match |
| 10k | q42 | original match |
| 10k | q43 | original match |
| 1m | q1 | original match |
| 1m | q2 | original match |
| 1m | q3 | original match |
| 1m | q4 | original match |
| 1m | q5 | original match |
| 1m | q6 | original match |
| 1m | q7 | original match |
| 1m | q8 | same rows; different order |
| 1m | q9 | original match |
| 1m | q10 | original match |
| 1m | q11 | original match |
| 1m | q12 | original match |
| 1m | q13 | same rows; different order |
| 1m | q14 | original match |
| 1m | q15 | original match |
| 1m | q16 | original selections differ; deterministic retest match |
| 1m | q17 | same rows; different order |
| 1m | q18 | original selections differ; deterministic retest match |
| 1m | q19 | original selections differ; deterministic retest match |
| 1m | q20 | original match |
| 1m | q21 | original match |
| 1m | q22 | same rows; different order |
| 1m | q23 | original selections differ; deterministic retest match |
| 1m | q24 | original match |
| 1m | q25 | original match |
| 1m | q26 | original match |
| 1m | q27 | original match |
| 1m | q28 | original match |
| 1m | q29 | original match |
| 1m | q30 | original match |
| 1m | q31 | same rows; different order |
| 1m | q32 | original selections differ; deterministic retest match |
| 1m | q33 | original selections differ; deterministic retest match |
| 1m | q34 | original match |
| 1m | q35 | original match |
| 1m | q36 | same rows; different order |
| 1m | q37 | same rows; different order |
| 1m | q38 | same rows; different order |
| 1m | q39 | original match |
| 1m | q40 | original selections differ; deterministic retest match |
| 1m | q41 | original selections differ; deterministic retest match |
| 1m | q42 | original match |
| 1m | q43 | original match |
| 10m | q1 | original match |
| 10m | q2 | original match |
| 10m | q3 | original match |
| 10m | q4 | original match |
| 10m | q5 | original match |
| 10m | q6 | original match |
| 10m | q7 | original match |
| 10m | q8 | original match |
| 10m | q9 | original match |
| 10m | q10 | original match |
| 10m | q11 | original match |
| 10m | q12 | original match |
| 10m | q13 | original match |
| 10m | q14 | original match |
| 10m | q15 | original match |
| 10m | q16 | original match |
| 10m | q17 | original match |
| 10m | q18 | original selections differ; deterministic retest match |
| 10m | q19 | same rows; different order |
| 10m | q20 | original match |
| 10m | q21 | original match |
| 10m | q22 | original selections differ; deterministic retest match |
| 10m | q23 | same rows; different order |
| 10m | q24 | original match |
| 10m | q25 | same rows; different order |
| 10m | q26 | original match |
| 10m | q27 | original match |
| 10m | q28 | original match |
| 10m | q29 | original match |
| 10m | q30 | original match |
| 10m | q31 | same rows; different order |
| 10m | q32 | original selections differ; deterministic retest match |
| 10m | q33 | original selections differ; deterministic retest match |
| 10m | q34 | original match |
| 10m | q35 | original match |
| 10m | q36 | original match |
| 10m | q37 | original match |
| 10m | q38 | original match |
| 10m | q39 | original selections differ; deterministic retest match |
| 10m | q40 | original selections differ; deterministic retest match |
| 10m | q41 | original selections differ; deterministic retest match |
| 10m | q42 | original match |
| 10m | q43 | original match |

Answer checks retain original differences. Same rows with different ordering are reported separately; differing row selections are rerun with deterministic tie breakers in a separate untimed diagnostic. Those diagnostic queries are stored alongside the raw outputs and never replace the timed SQL.


| Size | Engine | Query | First query s | Hot median s | Hot IQR s | Hot process wall s | Hot CPU s | Peak RSS MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 1k | duckdb-native | q1 | 0.001000 | 0.000000 | 0.001000 | 0.020761 | 0.019511 | 19.91 |
| 1k | duckdb-native | q2 | 0.000000 | 0.001000 | 0.000000 | 0.018463 | 0.017778 | 19.53 |
| 1k | duckdb-native | q3 | 0.000000 | 0.001000 | 0.000000 | 0.017436 | 0.016912 | 19.45 |
| 1k | duckdb-native | q4 | 0.000000 | 0.001000 | 0.001000 | 0.016988 | 0.016058 | 19.00 |
| 1k | duckdb-native | q5 | 0.001000 | 0.001000 | 0.000000 | 0.017455 | 0.017129 | 22.47 |
| 1k | duckdb-native | q6 | 0.000000 | 0.001000 | 0.000000 | 0.017675 | 0.017458 | 24.59 |
| 1k | duckdb-native | q7 | 0.000000 | 0.001000 | 0.001000 | 0.018504 | 0.017490 | 19.44 |
| 1k | duckdb-native | q8 | 0.001000 | 0.001000 | 0.000000 | 0.019387 | 0.018748 | 21.14 |
| 1k | duckdb-native | q9 | 0.002000 | 0.002000 | 0.000000 | 0.021182 | 0.022172 | 30.84 |
| 1k | duckdb-native | q10 | 0.002000 | 0.002000 | 0.000000 | 0.021021 | 0.022845 | 33.59 |
| 1k | duckdb-native | q11 | 0.002000 | 0.002000 | 0.000000 | 0.021502 | 0.023063 | 31.45 |
| 1k | duckdb-native | q12 | 0.002000 | 0.002000 | 0.000000 | 0.022188 | 0.023514 | 31.77 |
| 1k | duckdb-native | q13 | 0.001000 | 0.001000 | 0.001000 | 0.022969 | 0.023017 | 26.30 |
| 1k | duckdb-native | q14 | 0.003000 | 0.002000 | 0.001000 | 0.021297 | 0.023395 | 32.34 |
| 1k | duckdb-native | q15 | 0.002000 | 0.001000 | 0.001000 | 0.021753 | 0.022281 | 26.75 |
| 1k | duckdb-native | q16 | 0.002000 | 0.001000 | 0.000000 | 0.021628 | 0.022151 | 26.14 |
| 1k | duckdb-native | q17 | 0.002000 | 0.002000 | 0.000000 | 0.020784 | 0.021119 | 27.67 |
| 1k | duckdb-native | q18 | 0.002000 | 0.002000 | 0.000000 | 0.020674 | 0.020755 | 26.33 |
| 1k | duckdb-native | q19 | 0.002000 | 0.002000 | 0.000000 | 0.020787 | 0.021620 | 28.14 |
| 1k | duckdb-native | q20 | 0.000000 | 0.001000 | 0.001000 | 0.018639 | 0.017428 | 19.55 |
| 1k | duckdb-native | q21 | 0.001000 | 0.001000 | 0.001000 | 0.018697 | 0.017619 | 20.09 |
| 1k | duckdb-native | q22 | 0.001000 | 0.001000 | 0.000000 | 0.017790 | 0.017278 | 20.52 |
| 1k | duckdb-native | q23 | 0.001000 | 0.001000 | 0.000000 | 0.018907 | 0.018471 | 21.70 |
| 1k | duckdb-native | q24 | 0.004000 | 0.004000 | 0.001000 | 0.022962 | 0.023466 | 35.72 |
| 1k | duckdb-native | q25 | 0.001000 | 0.002000 | 0.001000 | 0.020514 | 0.020240 | 22.58 |
| 1k | duckdb-native | q26 | 0.001000 | 0.000000 | 0.001000 | 0.019631 | 0.018654 | 19.52 |
| 1k | duckdb-native | q27 | 0.001000 | 0.001000 | 0.000000 | 0.019538 | 0.018495 | 20.28 |
| 1k | duckdb-native | q28 | 0.001000 | 0.002000 | 0.000000 | 0.020329 | 0.021229 | 26.11 |
| 1k | duckdb-native | q29 | 0.003000 | 0.002000 | 0.000000 | 0.021453 | 0.023112 | 27.58 |
| 1k | duckdb-native | q30 | 0.005000 | 0.005000 | 0.001000 | 0.024645 | 0.023768 | 29.92 |
| 1k | duckdb-native | q31 | 0.002000 | 0.002000 | 0.000000 | 0.021713 | 0.022444 | 28.09 |
| 1k | duckdb-native | q32 | 0.002000 | 0.002000 | 0.001000 | 0.021622 | 0.022166 | 27.66 |
| 1k | duckdb-native | q33 | 0.002000 | 0.002000 | 0.000000 | 0.021744 | 0.022452 | 27.97 |
| 1k | duckdb-native | q34 | 0.002000 | 0.002000 | 0.001000 | 0.022896 | 0.024560 | 26.69 |
| 1k | duckdb-native | q35 | 0.001000 | 0.002000 | 0.001000 | 0.020664 | 0.022095 | 27.05 |
| 1k | duckdb-native | q36 | 0.002000 | 0.002000 | 0.000000 | 0.022571 | 0.022740 | 27.55 |
| 1k | duckdb-native | q37 | 0.002000 | 0.002000 | 0.000000 | 0.020950 | 0.021749 | 25.55 |
| 1k | duckdb-native | q38 | 0.002000 | 0.002000 | 0.001000 | 0.021825 | 0.022002 | 24.73 |
| 1k | duckdb-native | q39 | 0.002000 | 0.001000 | 0.000000 | 0.020478 | 0.019444 | 20.86 |
| 1k | duckdb-native | q40 | 0.003000 | 0.002000 | 0.000000 | 0.021725 | 0.021725 | 28.59 |
| 1k | duckdb-native | q41 | 0.002000 | 0.001000 | 0.001000 | 0.021446 | 0.021196 | 25.08 |
| 1k | duckdb-native | q42 | 0.001000 | 0.002000 | 0.000000 | 0.021082 | 0.021200 | 24.17 |
| 1k | duckdb-native | q43 | 0.003000 | 0.001000 | 0.000000 | 0.023076 | 0.022568 | 26.19 |
| 1k | rudb-native | q1 | 0.000807 | 0.000719 | 0.000048 | 0.006799 | 0.005748 | 10.22 |
| 1k | rudb-native | q2 | 0.003658 | 0.000734 | 0.000614 | 0.006391 | 0.005212 | 9.36 |
| 1k | rudb-native | q3 | 0.000675 | 0.000641 | 0.000056 | 0.005697 | 0.004840 | 9.52 |
| 1k | rudb-native | q4 | 0.000577 | 0.000611 | 0.000058 | 0.005530 | 0.004682 | 9.17 |
| 1k | rudb-native | q5 | 0.000571 | 0.000593 | 0.000015 | 0.005472 | 0.004617 | 9.11 |
| 1k | rudb-native | q6 | 0.000571 | 0.000608 | 0.000064 | 0.005836 | 0.004981 | 9.64 |
| 1k | rudb-native | q7 | 0.000609 | 0.000663 | 0.000036 | 0.006294 | 0.005269 | 9.34 |
| 1k | rudb-native | q8 | 0.001121 | 0.000977 | 0.000036 | 0.006514 | 0.005508 | 11.08 |
| 1k | rudb-native | q9 | 0.000995 | 0.000980 | 0.000085 | 0.006886 | 0.005651 | 11.17 |
| 1k | rudb-native | q10 | 0.001229 | 0.001304 | 0.000054 | 0.006886 | 0.005926 | 10.92 |
| 1k | rudb-native | q11 | 0.000997 | 0.001104 | 0.000061 | 0.007122 | 0.006102 | 10.86 |
| 1k | rudb-native | q12 | 0.001134 | 0.001085 | 0.000045 | 0.006980 | 0.006011 | 10.67 |
| 1k | rudb-native | q13 | 0.001205 | 0.001176 | 0.000048 | 0.007265 | 0.006243 | 11.55 |
| 1k | rudb-native | q14 | 0.001091 | 0.001097 | 0.000028 | 0.006907 | 0.005830 | 10.91 |
| 1k | rudb-native | q15 | 0.001259 | 0.001231 | 0.000040 | 0.007107 | 0.005935 | 11.52 |
| 1k | rudb-native | q16 | 0.000877 | 0.000783 | 0.000018 | 0.006604 | 0.005606 | 9.89 |
| 1k | rudb-native | q17 | 0.000858 | 0.000809 | 0.000012 | 0.006462 | 0.005531 | 9.70 |
| 1k | rudb-native | q18 | 0.000737 | 0.000799 | 0.000144 | 0.006595 | 0.005500 | 10.09 |
| 1k | rudb-native | q19 | 0.000876 | 0.000867 | 0.000019 | 0.006491 | 0.005431 | 10.66 |
| 1k | rudb-native | q20 | 0.000676 | 0.000641 | 0.000018 | 0.006010 | 0.005061 | 9.48 |
| 1k | rudb-native | q21 | 0.000949 | 0.000907 | 0.000059 | 0.005926 | 0.005045 | 10.61 |
| 1k | rudb-native | q22 | 0.001004 | 0.000982 | 0.000190 | 0.006113 | 0.005193 | 11.72 |
| 1k | rudb-native | q23 | 0.001074 | 0.001077 | 0.000129 | 0.006573 | 0.005638 | 10.89 |
| 1k | rudb-native | q24 | 0.000989 | 0.000961 | 0.000030 | 0.006317 | 0.005363 | 10.47 |
| 1k | rudb-native | q25 | 0.000854 | 0.000970 | 0.000142 | 0.006762 | 0.005782 | 10.86 |
| 1k | rudb-native | q26 | 0.000844 | 0.000877 | 0.000045 | 0.006479 | 0.005516 | 9.81 |
| 1k | rudb-native | q27 | 0.000854 | 0.000924 | 0.000145 | 0.006456 | 0.005548 | 10.47 |
| 1k | rudb-native | q28 | 0.001176 | 0.001152 | 0.000063 | 0.007035 | 0.005997 | 10.89 |
| 1k | rudb-native | q29 | 0.001507 | 0.001386 | 0.000055 | 0.007307 | 0.006237 | 12.06 |
| 1k | rudb-native | q30 | 0.003044 | 0.003078 | 0.000198 | 0.008880 | 0.007795 | 11.11 |
| 1k | rudb-native | q31 | 0.001445 | 0.001338 | 0.000070 | 0.006912 | 0.005964 | 11.08 |
| 1k | rudb-native | q32 | 0.001022 | 0.001019 | 0.000116 | 0.006888 | 0.005974 | 10.25 |
| 1k | rudb-native | q33 | 0.000941 | 0.000928 | 0.000073 | 0.006770 | 0.005723 | 10.33 |
| 1k | rudb-native | q34 | 0.000865 | 0.000934 | 0.000053 | 0.006871 | 0.005825 | 10.38 |
| 1k | rudb-native | q35 | 0.001151 | 0.001254 | 0.000057 | 0.007114 | 0.006263 | 11.23 |
| 1k | rudb-native | q36 | 0.001277 | 0.001185 | 0.000023 | 0.007376 | 0.006326 | 10.94 |
| 1k | rudb-native | q37 | 0.001670 | 0.001440 | 0.000263 | 0.007529 | 0.006531 | 12.20 |
| 1k | rudb-native | q38 | 0.001622 | 0.001475 | 0.000228 | 0.007541 | 0.006675 | 12.27 |
| 1k | rudb-native | q39 | 0.001022 | 0.001046 | 0.000049 | 0.007249 | 0.006158 | 11.27 |
| 1k | rudb-native | q40 | 0.001172 | 0.001224 | 0.000156 | 0.007178 | 0.006152 | 10.95 |
| 1k | rudb-native | q41 | 0.001184 | 0.001112 | 0.000098 | 0.006793 | 0.005859 | 11.16 |
| 1k | rudb-native | q42 | 0.001175 | 0.001116 | 0.000104 | 0.006749 | 0.005802 | 11.09 |
| 1k | rudb-native | q43 | 0.001134 | 0.001217 | 0.000070 | 0.007436 | 0.006551 | 12.84 |
| 1k | duckdb-parquet | q1 | 0.002000 | 0.001000 | 0.000000 | 0.021729 | 0.020552 | 20.03 |
| 1k | duckdb-parquet | q2 | 0.001000 | 0.001000 | 0.000000 | 0.021712 | 0.018916 | 20.14 |
| 1k | duckdb-parquet | q3 | 0.001000 | 0.001000 | 0.000000 | 0.017647 | 0.016843 | 18.84 |
| 1k | duckdb-parquet | q4 | 0.001000 | 0.001000 | 0.000000 | 0.017644 | 0.016358 | 19.33 |
| 1k | duckdb-parquet | q5 | 0.001000 | 0.001000 | 0.001000 | 0.017746 | 0.017307 | 22.80 |
| 1k | duckdb-parquet | q6 | 0.001000 | 0.001000 | 0.000000 | 0.017607 | 0.017519 | 23.48 |
| 1k | duckdb-parquet | q7 | 0.001000 | 0.001000 | 0.000000 | 0.017957 | 0.016934 | 19.12 |
| 1k | duckdb-parquet | q8 | 0.002000 | 0.001000 | 0.000000 | 0.019163 | 0.018547 | 20.02 |
| 1k | duckdb-parquet | q9 | 0.002000 | 0.002000 | 0.000000 | 0.021361 | 0.022941 | 30.98 |
| 1k | duckdb-parquet | q10 | 0.002000 | 0.003000 | 0.001000 | 0.021712 | 0.023757 | 33.03 |
| 1k | duckdb-parquet | q11 | 0.003000 | 0.002000 | 0.001000 | 0.022192 | 0.023551 | 29.95 |
| 1k | duckdb-parquet | q12 | 0.002000 | 0.002000 | 0.000000 | 0.022838 | 0.023199 | 31.34 |
| 1k | duckdb-parquet | q13 | 0.002000 | 0.002000 | 0.000000 | 0.022265 | 0.022783 | 25.97 |
| 1k | duckdb-parquet | q14 | 0.002000 | 0.002000 | 0.001000 | 0.021964 | 0.024227 | 32.12 |
| 1k | duckdb-parquet | q15 | 0.002000 | 0.002000 | 0.000000 | 0.022673 | 0.023936 | 25.56 |
| 1k | duckdb-parquet | q16 | 0.002000 | 0.002000 | 0.000000 | 0.021578 | 0.021476 | 25.28 |
| 1k | duckdb-parquet | q17 | 0.002000 | 0.002000 | 0.000000 | 0.020360 | 0.020985 | 26.41 |
| 1k | duckdb-parquet | q18 | 0.002000 | 0.002000 | 0.000000 | 0.021041 | 0.020990 | 24.70 |
| 1k | duckdb-parquet | q19 | 0.003000 | 0.002000 | 0.001000 | 0.020382 | 0.021327 | 27.39 |
| 1k | duckdb-parquet | q20 | 0.001000 | 0.001000 | 0.000000 | 0.018722 | 0.017870 | 18.89 |
| 1k | duckdb-parquet | q21 | 0.001000 | 0.001000 | 0.000000 | 0.017832 | 0.017091 | 20.06 |
| 1k | duckdb-parquet | q22 | 0.001000 | 0.001000 | 0.000000 | 0.018115 | 0.017424 | 19.47 |
| 1k | duckdb-parquet | q23 | 0.001000 | 0.001000 | 0.001000 | 0.019346 | 0.018806 | 20.41 |
| 1k | duckdb-parquet | q24 | 0.004000 | 0.005000 | 0.000000 | 0.023138 | 0.023521 | 32.83 |
| 1k | duckdb-parquet | q25 | 0.002000 | 0.002000 | 0.000000 | 0.020823 | 0.020543 | 22.36 |
| 1k | duckdb-parquet | q26 | 0.001000 | 0.001000 | 0.000000 | 0.019266 | 0.018582 | 19.12 |
| 1k | duckdb-parquet | q27 | 0.001000 | 0.001000 | 0.000000 | 0.019866 | 0.019171 | 19.86 |
| 1k | duckdb-parquet | q28 | 0.002000 | 0.002000 | 0.001000 | 0.020755 | 0.021934 | 25.41 |
| 1k | duckdb-parquet | q29 | 0.003000 | 0.003000 | 0.000000 | 0.021865 | 0.023195 | 26.92 |
| 1k | duckdb-parquet | q30 | 0.005000 | 0.005000 | 0.001000 | 0.025014 | 0.024792 | 30.38 |
| 1k | duckdb-parquet | q31 | 0.002000 | 0.003000 | 0.001000 | 0.021688 | 0.022570 | 27.45 |
| 1k | duckdb-parquet | q32 | 0.002000 | 0.002000 | 0.000000 | 0.021751 | 0.022659 | 26.94 |
| 1k | duckdb-parquet | q33 | 0.002000 | 0.002000 | 0.000000 | 0.020706 | 0.021516 | 27.05 |
| 1k | duckdb-parquet | q34 | 0.002000 | 0.002000 | 0.001000 | 0.021905 | 0.023256 | 26.17 |
| 1k | duckdb-parquet | q35 | 0.002000 | 0.002000 | 0.000000 | 0.021201 | 0.021735 | 25.98 |
| 1k | duckdb-parquet | q36 | 0.002000 | 0.002000 | 0.000000 | 0.022306 | 0.022758 | 26.33 |
| 1k | duckdb-parquet | q37 | 0.002000 | 0.002000 | 0.000000 | 0.022162 | 0.022590 | 25.27 |
| 1k | duckdb-parquet | q38 | 0.002000 | 0.002000 | 0.000000 | 0.021778 | 0.022028 | 23.83 |
| 1k | duckdb-parquet | q39 | 0.003000 | 0.001000 | 0.001000 | 0.021099 | 0.020236 | 21.09 |
| 1k | duckdb-parquet | q40 | 0.002000 | 0.003000 | 0.000000 | 0.021750 | 0.022672 | 27.88 |
| 1k | duckdb-parquet | q41 | 0.002000 | 0.002000 | 0.001000 | 0.021686 | 0.021967 | 24.27 |
| 1k | duckdb-parquet | q42 | 0.002000 | 0.002000 | 0.000000 | 0.021059 | 0.020480 | 23.69 |
| 1k | duckdb-parquet | q43 | 0.004000 | 0.002000 | 0.000000 | 0.023558 | 0.024492 | 25.50 |
| 1k | rudb-parquet | q1 | 0.001453 | 0.001024 | 0.000166 | 0.007128 | 0.006145 | 10.20 |
| 1k | rudb-parquet | q2 | 0.001083 | 0.001039 | 0.000074 | 0.006702 | 0.005624 | 10.20 |
| 1k | rudb-parquet | q3 | 0.000952 | 0.000856 | 0.000021 | 0.005594 | 0.004750 | 9.59 |
| 1k | rudb-parquet | q4 | 0.000901 | 0.000807 | 0.000019 | 0.005411 | 0.004561 | 9.42 |
| 1k | rudb-parquet | q5 | 0.000869 | 0.000847 | 0.000139 | 0.005435 | 0.004643 | 9.59 |
| 1k | rudb-parquet | q6 | 0.000969 | 0.000934 | 0.000012 | 0.005371 | 0.004571 | 9.91 |
| 1k | rudb-parquet | q7 | 0.000671 | 0.000692 | 0.000109 | 0.005616 | 0.004843 | 9.27 |
| 1k | rudb-parquet | q8 | 0.001047 | 0.001081 | 0.000082 | 0.006357 | 0.005370 | 11.55 |
| 1k | rudb-parquet | q9 | 0.001023 | 0.001022 | 0.000036 | 0.006251 | 0.005251 | 10.38 |
| 1k | rudb-parquet | q10 | 0.001349 | 0.001287 | 0.000119 | 0.006409 | 0.005479 | 10.19 |
| 1k | rudb-parquet | q11 | 0.001169 | 0.001091 | 0.000083 | 0.006603 | 0.005612 | 10.73 |
| 1k | rudb-parquet | q12 | 0.001170 | 0.001125 | 0.000089 | 0.006962 | 0.005944 | 10.42 |
| 1k | rudb-parquet | q13 | 0.001175 | 0.001197 | 0.000158 | 0.006978 | 0.005909 | 10.39 |
| 1k | rudb-parquet | q14 | 0.001218 | 0.001200 | 0.000091 | 0.006738 | 0.005723 | 10.66 |
| 1k | rudb-parquet | q15 | 0.001348 | 0.001203 | 0.000042 | 0.006579 | 0.005628 | 9.80 |
| 1k | rudb-parquet | q16 | 0.001112 | 0.001131 | 0.000021 | 0.007322 | 0.006210 | 9.98 |
| 1k | rudb-parquet | q17 | 0.001163 | 0.001171 | 0.000038 | 0.006903 | 0.005869 | 10.55 |
| 1k | rudb-parquet | q18 | 0.001021 | 0.000997 | 0.000045 | 0.006360 | 0.005360 | 9.86 |
| 1k | rudb-parquet | q19 | 0.001250 | 0.001234 | 0.000088 | 0.006308 | 0.005360 | 9.98 |
| 1k | rudb-parquet | q20 | 0.000815 | 0.000726 | 0.000077 | 0.005436 | 0.004683 | 9.42 |
| 1k | rudb-parquet | q21 | 0.001100 | 0.001087 | 0.000083 | 0.005757 | 0.004997 | 9.89 |
| 1k | rudb-parquet | q22 | 0.001185 | 0.001145 | 0.000031 | 0.005870 | 0.005050 | 10.59 |
| 1k | rudb-parquet | q23 | 0.001610 | 0.001456 | 0.000064 | 0.006445 | 0.005548 | 10.48 |
| 1k | rudb-parquet | q24 | 0.001191 | 0.001171 | 0.000031 | 0.006352 | 0.005361 | 9.77 |
| 1k | rudb-parquet | q25 | 0.000895 | 0.000979 | 0.000089 | 0.006393 | 0.005292 | 9.48 |
| 1k | rudb-parquet | q26 | 0.001037 | 0.000908 | 0.000120 | 0.006193 | 0.005277 | 9.23 |
| 1k | rudb-parquet | q27 | 0.000957 | 0.001031 | 0.000026 | 0.006524 | 0.005603 | 9.58 |
| 1k | rudb-parquet | q28 | 0.001320 | 0.001290 | 0.000054 | 0.006782 | 0.005859 | 10.56 |
| 1k | rudb-parquet | q29 | 0.001504 | 0.001495 | 0.000039 | 0.006908 | 0.005929 | 10.67 |
| 1k | rudb-parquet | q30 | 0.003672 | 0.003507 | 0.000191 | 0.008892 | 0.007907 | 11.14 |
| 1k | rudb-parquet | q31 | 0.001330 | 0.001391 | 0.000058 | 0.006955 | 0.005949 | 10.61 |
| 1k | rudb-parquet | q32 | 0.001383 | 0.001404 | 0.000185 | 0.006588 | 0.005664 | 10.48 |
| 1k | rudb-parquet | q33 | 0.001543 | 0.001398 | 0.000029 | 0.006690 | 0.005679 | 10.06 |
| 1k | rudb-parquet | q34 | 0.001481 | 0.001356 | 0.000074 | 0.006876 | 0.005815 | 10.84 |
| 1k | rudb-parquet | q35 | 0.001277 | 0.001254 | 0.000070 | 0.006733 | 0.005736 | 10.33 |
| 1k | rudb-parquet | q36 | 0.001231 | 0.001246 | 0.000012 | 0.006897 | 0.005856 | 10.45 |
| 1k | rudb-parquet | q37 | 0.001518 | 0.001381 | 0.000172 | 0.006787 | 0.005973 | 10.70 |
| 1k | rudb-parquet | q38 | 0.001487 | 0.001530 | 0.000107 | 0.007053 | 0.005979 | 10.39 |
| 1k | rudb-parquet | q39 | 0.001485 | 0.001324 | 0.000049 | 0.006544 | 0.005624 | 10.59 |
| 1k | rudb-parquet | q40 | 0.001574 | 0.001572 | 0.000092 | 0.007128 | 0.005978 | 10.67 |
| 1k | rudb-parquet | q41 | 0.001241 | 0.001274 | 0.000041 | 0.006751 | 0.005734 | 10.17 |
| 1k | rudb-parquet | q42 | 0.001131 | 0.001193 | 0.000092 | 0.006794 | 0.005799 | 10.08 |
| 1k | rudb-parquet | q43 | 0.001287 | 0.001375 | 0.000174 | 0.006984 | 0.005948 | 11.03 |
| 10k | duckdb-native | q1 | 0.001000 | 0.001000 | 0.000000 | 0.019192 | 0.018103 | 19.02 |
| 10k | duckdb-native | q2 | 0.001000 | 0.001000 | 0.000000 | 0.019098 | 0.018149 | 19.03 |
| 10k | duckdb-native | q3 | 0.001000 | 0.001000 | 0.001000 | 0.020625 | 0.019577 | 19.88 |
| 10k | duckdb-native | q4 | 0.000000 | 0.001000 | 0.001000 | 0.019595 | 0.018589 | 19.23 |
| 10k | duckdb-native | q5 | 0.001000 | 0.001000 | 0.000000 | 0.021451 | 0.022068 | 25.25 |
| 10k | duckdb-native | q6 | 0.001000 | 0.001000 | 0.000000 | 0.020974 | 0.020641 | 24.48 |
| 10k | duckdb-native | q7 | 0.001000 | 0.001000 | 0.000000 | 0.019225 | 0.018718 | 19.98 |
| 10k | duckdb-native | q8 | 0.001000 | 0.001000 | 0.000000 | 0.020705 | 0.020014 | 21.16 |
| 10k | duckdb-native | q9 | 0.002000 | 0.002000 | 0.000000 | 0.021184 | 0.025056 | 32.77 |
| 10k | duckdb-native | q10 | 0.003000 | 0.003000 | 0.001000 | 0.022655 | 0.025271 | 34.47 |
| 10k | duckdb-native | q11 | 0.001000 | 0.002000 | 0.000000 | 0.022552 | 0.024216 | 31.70 |
| 10k | duckdb-native | q12 | 0.003000 | 0.002000 | 0.000000 | 0.022241 | 0.024188 | 32.58 |
| 10k | duckdb-native | q13 | 0.002000 | 0.001000 | 0.001000 | 0.021535 | 0.022031 | 26.70 |
| 10k | duckdb-native | q14 | 0.001000 | 0.002000 | 0.000000 | 0.022249 | 0.024981 | 32.75 |
| 10k | duckdb-native | q15 | 0.001000 | 0.002000 | 0.001000 | 0.021909 | 0.022848 | 26.75 |
| 10k | duckdb-native | q16 | 0.002000 | 0.002000 | 0.000000 | 0.021530 | 0.022732 | 26.81 |
| 10k | duckdb-native | q17 | 0.003000 | 0.002000 | 0.001000 | 0.022122 | 0.023501 | 28.53 |
| 10k | duckdb-native | q18 | 0.002000 | 0.002000 | 0.000000 | 0.022068 | 0.021644 | 27.02 |
| 10k | duckdb-native | q19 | 0.002000 | 0.002000 | 0.001000 | 0.023215 | 0.023952 | 29.36 |
| 10k | duckdb-native | q20 | 0.000000 | 0.000000 | 0.000000 | 0.021094 | 0.019450 | 19.92 |
| 10k | duckdb-native | q21 | 0.001000 | 0.002000 | 0.000000 | 0.021383 | 0.021218 | 20.89 |
| 10k | duckdb-native | q22 | 0.002000 | 0.002000 | 0.001000 | 0.020765 | 0.020535 | 21.67 |
| 10k | duckdb-native | q23 | 0.003000 | 0.003000 | 0.000000 | 0.022268 | 0.023161 | 29.80 |
| 10k | duckdb-native | q24 | 0.006000 | 0.005000 | 0.001000 | 0.024758 | 0.026296 | 37.66 |
| 10k | duckdb-native | q25 | 0.002000 | 0.001000 | 0.001000 | 0.021528 | 0.021144 | 23.02 |
| 10k | duckdb-native | q26 | 0.001000 | 0.001000 | 0.000000 | 0.020065 | 0.019053 | 19.67 |
| 10k | duckdb-native | q27 | 0.001000 | 0.001000 | 0.000000 | 0.022749 | 0.021749 | 22.02 |
| 10k | duckdb-native | q28 | 0.002000 | 0.002000 | 0.000000 | 0.023327 | 0.023617 | 27.53 |
| 10k | duckdb-native | q29 | 0.008000 | 0.008000 | 0.000000 | 0.026788 | 0.033911 | 29.23 |
| 10k | duckdb-native | q30 | 0.005000 | 0.005000 | 0.001000 | 0.021853 | 0.021023 | 30.31 |
| 10k | duckdb-native | q31 | 0.002000 | 0.002000 | 0.000000 | 0.019763 | 0.020129 | 28.14 |
| 10k | duckdb-native | q32 | 0.002000 | 0.002000 | 0.000000 | 0.019227 | 0.020010 | 28.48 |
| 10k | duckdb-native | q33 | 0.002000 | 0.002000 | 0.000000 | 0.019011 | 0.020298 | 29.03 |
| 10k | duckdb-native | q34 | 0.002000 | 0.002000 | 0.000000 | 0.020201 | 0.020980 | 29.19 |
| 10k | duckdb-native | q35 | 0.001000 | 0.002000 | 0.000000 | 0.018926 | 0.020335 | 29.47 |
| 10k | duckdb-native | q36 | 0.002000 | 0.003000 | 0.001000 | 0.024180 | 0.025394 | 28.61 |
| 10k | duckdb-native | q37 | 0.002000 | 0.002000 | 0.001000 | 0.031108 | 0.025473 | 27.42 |
| 10k | duckdb-native | q38 | 0.002000 | 0.002000 | 0.000000 | 0.022154 | 0.023310 | 27.33 |
| 10k | duckdb-native | q39 | 0.001000 | 0.002000 | 0.000000 | 0.021097 | 0.021467 | 27.58 |
| 10k | duckdb-native | q40 | 0.002000 | 0.002000 | 0.000000 | 0.020517 | 0.021971 | 29.80 |
| 10k | duckdb-native | q41 | 0.002000 | 0.002000 | 0.001000 | 0.020293 | 0.020656 | 27.53 |
| 10k | duckdb-native | q42 | 0.001000 | 0.002000 | 0.001000 | 0.021177 | 0.021819 | 26.84 |
| 10k | duckdb-native | q43 | 0.002000 | 0.002000 | 0.000000 | 0.020693 | 0.021775 | 26.70 |
| 10k | rudb-native | q1 | 0.000647 | 0.000629 | 0.000030 | 0.006523 | 0.005627 | 9.19 |
| 10k | rudb-native | q2 | 0.000782 | 0.000721 | 0.000119 | 0.006687 | 0.005786 | 9.95 |
| 10k | rudb-native | q3 | 0.000756 | 0.000754 | 0.000066 | 0.007058 | 0.006094 | 10.45 |
| 10k | rudb-native | q4 | 0.000679 | 0.000657 | 0.000014 | 0.006564 | 0.005608 | 9.25 |
| 10k | rudb-native | q5 | 0.000671 | 0.000685 | 0.000041 | 0.006841 | 0.005829 | 9.33 |
| 10k | rudb-native | q6 | 0.000799 | 0.000672 | 0.000027 | 0.006593 | 0.005685 | 9.62 |
| 10k | rudb-native | q7 | 0.000715 | 0.000692 | 0.000025 | 0.006694 | 0.005730 | 9.77 |
| 10k | rudb-native | q8 | 0.001159 | 0.001130 | 0.000254 | 0.007340 | 0.006368 | 11.98 |
| 10k | rudb-native | q9 | 0.001183 | 0.001289 | 0.000147 | 0.007244 | 0.006321 | 11.45 |
| 10k | rudb-native | q10 | 0.001707 | 0.001689 | 0.000066 | 0.007551 | 0.006639 | 11.55 |
| 10k | rudb-native | q11 | 0.001143 | 0.001225 | 0.000128 | 0.008097 | 0.007070 | 12.22 |
| 10k | rudb-native | q12 | 0.001671 | 0.001258 | 0.000222 | 0.007544 | 0.006632 | 12.22 |
| 10k | rudb-native | q13 | 0.001597 | 0.001355 | 0.000134 | 0.007733 | 0.007166 | 12.05 |
| 10k | rudb-native | q14 | 0.001396 | 0.001359 | 0.000127 | 0.007450 | 0.006599 | 11.92 |
| 10k | rudb-native | q15 | 0.002212 | 0.001731 | 0.000077 | 0.008104 | 0.007297 | 12.69 |
| 10k | rudb-native | q16 | 0.001255 | 0.001209 | 0.000193 | 0.007754 | 0.006367 | 11.91 |
| 10k | rudb-native | q17 | 0.001640 | 0.001630 | 0.000037 | 0.007787 | 0.007195 | 12.52 |
| 10k | rudb-native | q18 | 0.001093 | 0.001150 | 0.000293 | 0.008474 | 0.007039 | 11.05 |
| 10k | rudb-native | q19 | 0.001754 | 0.001823 | 0.000109 | 0.008205 | 0.007406 | 12.56 |
| 10k | rudb-native | q20 | 0.000647 | 0.000719 | 0.000028 | 0.007631 | 0.006412 | 9.67 |
| 10k | rudb-native | q21 | 0.001022 | 0.001044 | 0.000052 | 0.007275 | 0.006221 | 10.77 |
| 10k | rudb-native | q22 | 0.001138 | 0.001143 | 0.000080 | 0.007164 | 0.006382 | 11.36 |
| 10k | rudb-native | q23 | 0.002266 | 0.002303 | 0.000142 | 0.008707 | 0.008317 | 13.91 |
| 10k | rudb-native | q24 | 0.001082 | 0.001023 | 0.000066 | 0.006803 | 0.005871 | 10.38 |
| 10k | rudb-native | q25 | 0.001100 | 0.001209 | 0.000106 | 0.007211 | 0.006198 | 10.62 |
| 10k | rudb-native | q26 | 0.001049 | 0.001050 | 0.000081 | 0.007081 | 0.006009 | 10.30 |
| 10k | rudb-native | q27 | 0.001217 | 0.001181 | 0.000054 | 0.008935 | 0.007145 | 11.56 |
| 10k | rudb-native | q28 | 0.002208 | 0.001603 | 0.000311 | 0.008520 | 0.007632 | 13.22 |
| 10k | rudb-native | q29 | 0.002530 | 0.002299 | 0.000001 | 0.008102 | 0.008366 | 13.67 |
| 10k | rudb-native | q30 | 0.002701 | 0.002699 | 0.000061 | 0.008046 | 0.007106 | 10.94 |
| 10k | rudb-native | q31 | 0.001549 | 0.001429 | 0.000066 | 0.007065 | 0.006227 | 11.80 |
| 10k | rudb-native | q32 | 0.000975 | 0.001076 | 0.000070 | 0.006667 | 0.005655 | 10.88 |
| 10k | rudb-native | q33 | 0.000858 | 0.000847 | 0.000041 | 0.006172 | 0.005314 | 10.20 |
| 10k | rudb-native | q34 | 0.000988 | 0.000798 | 0.000049 | 0.006112 | 0.005290 | 10.06 |
| 10k | rudb-native | q35 | 0.001506 | 0.001433 | 0.000043 | 0.006774 | 0.006164 | 12.30 |
| 10k | rudb-native | q36 | 0.000963 | 0.001017 | 0.000095 | 0.007734 | 0.006599 | 11.00 |
| 10k | rudb-native | q37 | 0.001453 | 0.002285 | 0.001029 | 0.017576 | 0.010666 | 13.19 |
| 10k | rudb-native | q38 | 0.001884 | 0.001718 | 0.000226 | 0.008282 | 0.007721 | 13.11 |
| 10k | rudb-native | q39 | 0.001395 | 0.001178 | 0.000150 | 0.007221 | 0.006531 | 12.31 |
| 10k | rudb-native | q40 | 0.001216 | 0.001202 | 0.000019 | 0.006995 | 0.006184 | 11.67 |
| 10k | rudb-native | q41 | 0.001190 | 0.001129 | 0.000033 | 0.006919 | 0.006125 | 11.67 |
| 10k | rudb-native | q42 | 0.001131 | 0.001156 | 0.000075 | 0.007238 | 0.006351 | 12.11 |
| 10k | rudb-native | q43 | 0.001297 | 0.001239 | 0.000185 | 0.007580 | 0.006702 | 12.28 |
| 10k | duckdb-parquet | q1 | 0.001000 | 0.001000 | 0.000000 | 0.019605 | 0.018629 | 18.66 |
| 10k | duckdb-parquet | q2 | 0.001000 | 0.001000 | 0.000000 | 0.019826 | 0.019031 | 19.23 |
| 10k | duckdb-parquet | q3 | 0.002000 | 0.002000 | 0.001000 | 0.020732 | 0.019663 | 19.95 |
| 10k | duckdb-parquet | q4 | 0.001000 | 0.001000 | 0.000000 | 0.020019 | 0.019120 | 19.70 |
| 10k | duckdb-parquet | q5 | 0.002000 | 0.002000 | 0.000000 | 0.021457 | 0.021910 | 23.84 |
| 10k | duckdb-parquet | q6 | 0.003000 | 0.002000 | 0.000000 | 0.021685 | 0.021729 | 23.86 |
| 10k | duckdb-parquet | q7 | 0.001000 | 0.001000 | 0.000000 | 0.020070 | 0.019007 | 18.69 |
| 10k | duckdb-parquet | q8 | 0.002000 | 0.002000 | 0.000000 | 0.020480 | 0.019963 | 20.28 |
| 10k | duckdb-parquet | q9 | 0.003000 | 0.002000 | 0.001000 | 0.021879 | 0.023569 | 32.03 |
| 10k | duckdb-parquet | q10 | 0.003000 | 0.003000 | 0.000000 | 0.022421 | 0.024786 | 32.70 |
| 10k | duckdb-parquet | q11 | 0.002000 | 0.003000 | 0.001000 | 0.022721 | 0.024843 | 31.12 |
| 10k | duckdb-parquet | q12 | 0.002000 | 0.003000 | 0.001000 | 0.022119 | 0.024096 | 31.08 |
| 10k | duckdb-parquet | q13 | 0.003000 | 0.002000 | 0.000000 | 0.020713 | 0.021699 | 25.97 |
| 10k | duckdb-parquet | q14 | 0.002000 | 0.002000 | 0.001000 | 0.022450 | 0.024971 | 32.88 |
| 10k | duckdb-parquet | q15 | 0.002000 | 0.002000 | 0.000000 | 0.021756 | 0.023647 | 26.44 |
| 10k | duckdb-parquet | q16 | 0.002000 | 0.002000 | 0.000000 | 0.022874 | 0.022315 | 26.75 |
| 10k | duckdb-parquet | q17 | 0.003000 | 0.003000 | 0.001000 | 0.023411 | 0.024639 | 28.42 |
| 10k | duckdb-parquet | q18 | 0.002000 | 0.003000 | 0.000000 | 0.021783 | 0.022540 | 26.33 |
| 10k | duckdb-parquet | q19 | 0.003000 | 0.003000 | 0.001000 | 0.022785 | 0.024527 | 29.58 |
| 10k | duckdb-parquet | q20 | 0.001000 | 0.001000 | 0.001000 | 0.020515 | 0.019511 | 19.50 |
| 10k | duckdb-parquet | q21 | 0.002000 | 0.002000 | 0.000000 | 0.022228 | 0.020967 | 20.92 |
| 10k | duckdb-parquet | q22 | 0.002000 | 0.002000 | 0.000000 | 0.021379 | 0.020768 | 21.52 |
| 10k | duckdb-parquet | q23 | 0.004000 | 0.004000 | 0.000000 | 0.023780 | 0.025398 | 31.12 |
| 10k | duckdb-parquet | q24 | 0.009000 | 0.009000 | 0.001000 | 0.028698 | 0.029153 | 38.62 |
| 10k | duckdb-parquet | q25 | 0.003000 | 0.003000 | 0.001000 | 0.022044 | 0.021895 | 22.69 |
| 10k | duckdb-parquet | q26 | 0.001000 | 0.001000 | 0.000000 | 0.020483 | 0.019336 | 19.67 |
| 10k | duckdb-parquet | q27 | 0.001000 | 0.002000 | 0.000000 | 0.023667 | 0.021931 | 20.95 |
| 10k | duckdb-parquet | q28 | 0.004000 | 0.003000 | 0.000000 | 0.023490 | 0.023494 | 27.81 |
| 10k | duckdb-parquet | q29 | 0.011000 | 0.008000 | 0.001000 | 0.026986 | 0.034064 | 28.52 |
| 10k | duckdb-parquet | q30 | 0.005000 | 0.004000 | 0.000000 | 0.021524 | 0.021353 | 29.48 |
| 10k | duckdb-parquet | q31 | 0.002000 | 0.003000 | 0.001000 | 0.019263 | 0.020142 | 26.88 |
| 10k | duckdb-parquet | q32 | 0.002000 | 0.002000 | 0.000000 | 0.019735 | 0.020587 | 26.78 |
| 10k | duckdb-parquet | q33 | 0.002000 | 0.002000 | 0.001000 | 0.019061 | 0.020179 | 28.41 |
| 10k | duckdb-parquet | q34 | 0.003000 | 0.003000 | 0.000000 | 0.020332 | 0.022280 | 28.67 |
| 10k | duckdb-parquet | q35 | 0.003000 | 0.003000 | 0.000000 | 0.020202 | 0.021078 | 29.64 |
| 10k | duckdb-parquet | q36 | 0.002000 | 0.003000 | 0.001000 | 0.026168 | 0.026105 | 27.33 |
| 10k | duckdb-parquet | q37 | 0.003000 | 0.003000 | 0.001000 | 0.036268 | 0.028339 | 27.72 |
| 10k | duckdb-parquet | q38 | 0.003000 | 0.002000 | 0.001000 | 0.022730 | 0.024063 | 26.78 |
| 10k | duckdb-parquet | q39 | 0.003000 | 0.002000 | 0.000000 | 0.020515 | 0.021504 | 26.27 |
| 10k | duckdb-parquet | q40 | 0.003000 | 0.003000 | 0.001000 | 0.021536 | 0.023321 | 28.78 |
| 10k | duckdb-parquet | q41 | 0.002000 | 0.002000 | 0.000000 | 0.020922 | 0.020758 | 26.55 |
| 10k | duckdb-parquet | q42 | 0.002000 | 0.002000 | 0.001000 | 0.019462 | 0.019882 | 24.83 |
| 10k | duckdb-parquet | q43 | 0.002000 | 0.002000 | 0.000000 | 0.021031 | 0.021818 | 25.66 |
| 10k | rudb-parquet | q1 | 0.000965 | 0.000924 | 0.000042 | 0.006706 | 0.005732 | 10.19 |
| 10k | rudb-parquet | q2 | 0.001066 | 0.001002 | 0.000020 | 0.006353 | 0.005384 | 9.72 |
| 10k | rudb-parquet | q3 | 0.001031 | 0.001037 | 0.000027 | 0.006249 | 0.005348 | 9.89 |
| 10k | rudb-parquet | q4 | 0.001001 | 0.000952 | 0.000019 | 0.006256 | 0.005305 | 9.91 |
| 10k | rudb-parquet | q5 | 0.001118 | 0.001089 | 0.000025 | 0.006425 | 0.005515 | 9.86 |
| 10k | rudb-parquet | q6 | 0.001483 | 0.001530 | 0.000047 | 0.007235 | 0.006146 | 11.52 |
| 10k | rudb-parquet | q7 | 0.000727 | 0.000701 | 0.000032 | 0.006013 | 0.005090 | 8.70 |
| 10k | rudb-parquet | q8 | 0.001274 | 0.001168 | 0.000124 | 0.006422 | 0.005473 | 10.38 |
| 10k | rudb-parquet | q9 | 0.001295 | 0.001342 | 0.000081 | 0.006718 | 0.005582 | 10.53 |
| 10k | rudb-parquet | q10 | 0.002005 | 0.001869 | 0.000109 | 0.007063 | 0.006080 | 11.16 |
| 10k | rudb-parquet | q11 | 0.001238 | 0.001324 | 0.000070 | 0.006849 | 0.005800 | 10.95 |
| 10k | rudb-parquet | q12 | 0.001257 | 0.001289 | 0.000120 | 0.006745 | 0.005731 | 10.45 |
| 10k | rudb-parquet | q13 | 0.001461 | 0.001528 | 0.000079 | 0.007100 | 0.006081 | 10.61 |
| 10k | rudb-parquet | q14 | 0.001559 | 0.001588 | 0.000075 | 0.007098 | 0.006044 | 10.81 |
| 10k | rudb-parquet | q15 | 0.001532 | 0.001593 | 0.000100 | 0.007059 | 0.006070 | 10.91 |
| 10k | rudb-parquet | q16 | 0.004720 | 0.001445 | 0.000082 | 0.007134 | 0.006109 | 11.30 |
| 10k | rudb-parquet | q17 | 0.002193 | 0.002290 | 0.000228 | 0.008343 | 0.007239 | 12.17 |
| 10k | rudb-parquet | q18 | 0.001526 | 0.001573 | 0.000057 | 0.006888 | 0.005850 | 10.98 |
| 10k | rudb-parquet | q19 | 0.002468 | 0.002640 | 0.000115 | 0.008033 | 0.007027 | 12.58 |
| 10k | rudb-parquet | q20 | 0.000810 | 0.000825 | 0.000021 | 0.006507 | 0.005540 | 9.64 |
| 10k | rudb-parquet | q21 | 0.002640 | 0.002507 | 0.000172 | 0.008059 | 0.007029 | 11.69 |
| 10k | rudb-parquet | q22 | 0.002759 | 0.002673 | 0.000136 | 0.007858 | 0.006819 | 11.92 |
| 10k | rudb-parquet | q23 | 0.005285 | 0.005317 | 0.000031 | 0.010821 | 0.009698 | 13.95 |
| 10k | rudb-parquet | q24 | 0.002485 | 0.002514 | 0.000058 | 0.007858 | 0.006843 | 11.58 |
| 10k | rudb-parquet | q25 | 0.001312 | 0.001305 | 0.000046 | 0.006397 | 0.005487 | 9.73 |
| 10k | rudb-parquet | q26 | 0.001519 | 0.001340 | 0.000080 | 0.006847 | 0.005888 | 10.27 |
| 10k | rudb-parquet | q27 | 0.001381 | 0.001486 | 0.000067 | 0.007950 | 0.006423 | 10.20 |
| 10k | rudb-parquet | q28 | 0.002607 | 0.002728 | 0.000218 | 0.008692 | 0.007493 | 13.38 |
| 10k | rudb-parquet | q29 | 0.004120 | 0.003824 | 0.000019 | 0.009172 | 0.008158 | 13.17 |
| 10k | rudb-parquet | q30 | 0.003133 | 0.003020 | 0.000112 | 0.007712 | 0.006842 | 11.05 |
| 10k | rudb-parquet | q31 | 0.001749 | 0.001658 | 0.000054 | 0.006458 | 0.005579 | 10.67 |
| 10k | rudb-parquet | q32 | 0.001766 | 0.001683 | 0.000060 | 0.006554 | 0.005676 | 11.59 |
| 10k | rudb-parquet | q33 | 0.001412 | 0.001463 | 0.000069 | 0.006177 | 0.005481 | 11.16 |
| 10k | rudb-parquet | q34 | 0.002877 | 0.003016 | 0.000452 | 0.007930 | 0.006988 | 13.70 |
| 10k | rudb-parquet | q35 | 0.002943 | 0.002984 | 0.000105 | 0.007531 | 0.006700 | 13.55 |
| 10k | rudb-parquet | q36 | 0.001819 | 0.001617 | 0.000730 | 0.009089 | 0.007646 | 11.67 |
| 10k | rudb-parquet | q37 | 0.002722 | 0.003603 | 0.001636 | 0.010913 | 0.009333 | 13.27 |
| 10k | rudb-parquet | q38 | 0.004328 | 0.004225 | 0.000041 | 0.010480 | 0.008910 | 13.59 |
| 10k | rudb-parquet | q39 | 0.002679 | 0.002557 | 0.000252 | 0.007427 | 0.006485 | 12.27 |
| 10k | rudb-parquet | q40 | 0.003546 | 0.003561 | 0.000046 | 0.008888 | 0.007931 | 13.52 |
| 10k | rudb-parquet | q41 | 0.001454 | 0.001334 | 0.000061 | 0.006129 | 0.005354 | 11.17 |
| 10k | rudb-parquet | q42 | 0.001760 | 0.001381 | 0.000120 | 0.006470 | 0.005474 | 11.84 |
| 10k | rudb-parquet | q43 | 0.001377 | 0.001453 | 0.000114 | 0.006781 | 0.006124 | 10.80 |
| 1m | duckdb-native | q1 | 0.000000 | 0.000000 | 0.001000 | 0.017561 | 0.016527 | 18.91 |
| 1m | duckdb-native | q2 | 0.001000 | 0.001000 | 0.000000 | 0.018331 | 0.018453 | 22.73 |
| 1m | duckdb-native | q3 | 0.002000 | 0.002000 | 0.001000 | 0.019981 | 0.022543 | 25.66 |
| 1m | duckdb-native | q4 | 0.002000 | 0.002000 | 0.001000 | 0.018311 | 0.020947 | 29.83 |
| 1m | duckdb-native | q5 | 0.015000 | 0.014000 | 0.001000 | 0.038272 | 0.084257 | 64.89 |
| 1m | duckdb-native | q6 | 0.012000 | 0.009000 | 0.002000 | 0.030779 | 0.063764 | 52.98 |
| 1m | duckdb-native | q7 | 0.000000 | 0.001000 | 0.000000 | 0.024840 | 0.023322 | 21.17 |
| 1m | duckdb-native | q8 | 0.001000 | 0.002000 | 0.000000 | 0.022812 | 0.022872 | 24.48 |
| 1m | duckdb-native | q9 | 0.030000 | 0.022000 | 0.001000 | 0.049289 | 0.117552 | 78.36 |
| 1m | duckdb-native | q10 | 0.050000 | 0.027000 | 0.006000 | 0.056056 | 0.140149 | 85.72 |
| 1m | duckdb-native | q11 | 0.007000 | 0.005000 | 0.000000 | 0.027134 | 0.042431 | 50.31 |
| 1m | duckdb-native | q12 | 0.007000 | 0.005000 | 0.001000 | 0.027167 | 0.041753 | 52.00 |
| 1m | duckdb-native | q13 | 0.008000 | 0.008000 | 0.001000 | 0.029844 | 0.056264 | 57.05 |
| 1m | duckdb-native | q14 | 0.015000 | 0.012000 | 0.002000 | 0.034890 | 0.080730 | 83.67 |
| 1m | duckdb-native | q15 | 0.009000 | 0.009000 | 0.001000 | 0.031690 | 0.060390 | 59.62 |
| 1m | duckdb-native | q16 | 0.016000 | 0.017000 | 0.003000 | 0.039546 | 0.097880 | 76.00 |
| 1m | duckdb-native | q17 | 0.032000 | 0.033000 | 0.002000 | 0.059687 | 0.182419 | 159.08 |
| 1m | duckdb-native | q18 | 0.029000 | 0.026000 | 0.001000 | 0.048905 | 0.129863 | 136.36 |
| 1m | duckdb-native | q19 | 0.038000 | 0.036000 | 0.003000 | 0.064209 | 0.198716 | 169.89 |
| 1m | duckdb-native | q20 | 0.002000 | 0.002000 | 0.000000 | 0.025132 | 0.026558 | 29.36 |
| 1m | duckdb-native | q21 | 0.041000 | 0.032000 | 0.000000 | 0.061275 | 0.154536 | 88.69 |
| 1m | duckdb-native | q22 | 0.027000 | 0.029000 | 0.003000 | 0.058148 | 0.138627 | 101.20 |
| 1m | duckdb-native | q23 | 0.035000 | 0.026000 | 0.003000 | 0.053213 | 0.129285 | 120.56 |
| 1m | duckdb-native | q24 | 0.060000 | 0.047000 | 0.002000 | 0.083342 | 0.216619 | 224.31 |
| 1m | duckdb-native | q25 | 0.007000 | 0.006000 | 0.000000 | 0.032426 | 0.044179 | 37.39 |
| 1m | duckdb-native | q26 | 0.006000 | 0.005000 | 0.001000 | 0.031282 | 0.044887 | 30.70 |
| 1m | duckdb-native | q27 | 0.004000 | 0.005000 | 0.002000 | 0.031196 | 0.042778 | 34.05 |
| 1m | duckdb-native | q28 | 0.030000 | 0.024000 | 0.002000 | 0.050778 | 0.126291 | 96.27 |
| 1m | duckdb-native | q29 | 0.225000 | 0.239000 | 0.019000 | 0.271202 | 1.105201 | 138.59 |
| 1m | duckdb-native | q30 | 0.007000 | 0.007000 | 0.001000 | 0.030543 | 0.031973 | 34.28 |
| 1m | duckdb-native | q31 | 0.011000 | 0.011000 | 0.001000 | 0.033847 | 0.066694 | 62.03 |
| 1m | duckdb-native | q32 | 0.013000 | 0.011000 | 0.001000 | 0.035684 | 0.071968 | 72.67 |
| 1m | duckdb-native | q33 | 0.030000 | 0.032000 | 0.002000 | 0.055995 | 0.165117 | 134.23 |
| 1m | duckdb-native | q34 | 0.048000 | 0.053000 | 0.004000 | 0.081187 | 0.260566 | 222.61 |
| 1m | duckdb-native | q35 | 0.067000 | 0.059000 | 0.010000 | 0.097879 | 0.282805 | 269.86 |
| 1m | duckdb-native | q36 | 0.022000 | 0.021000 | 0.003000 | 0.048907 | 0.121845 | 77.16 |
| 1m | duckdb-native | q37 | 0.004000 | 0.004000 | 0.001000 | 0.027685 | 0.029608 | 32.48 |
| 1m | duckdb-native | q38 | 0.003000 | 0.003000 | 0.000000 | 0.024669 | 0.026739 | 31.48 |
| 1m | duckdb-native | q39 | 0.002000 | 0.003000 | 0.001000 | 0.022808 | 0.025035 | 31.30 |
| 1m | duckdb-native | q40 | 0.004000 | 0.005000 | 0.001000 | 0.025480 | 0.031668 | 40.50 |
| 1m | duckdb-native | q41 | 0.003000 | 0.003000 | 0.000000 | 0.025316 | 0.027202 | 31.14 |
| 1m | duckdb-native | q42 | 0.002000 | 0.003000 | 0.001000 | 0.026163 | 0.027450 | 30.58 |
| 1m | duckdb-native | q43 | 0.003000 | 0.002000 | 0.000000 | 0.023539 | 0.025735 | 29.66 |
| 1m | rudb-native | q1 | 0.000875 | 0.000627 | 0.000099 | 0.006236 | 0.005391 | 9.34 |
| 1m | rudb-native | q2 | 0.000656 | 0.000666 | 0.000032 | 0.006062 | 0.005221 | 9.70 |
| 1m | rudb-native | q3 | 0.000642 | 0.000713 | 0.000093 | 0.006587 | 0.005653 | 9.67 |
| 1m | rudb-native | q4 | 0.000711 | 0.000633 | 0.000045 | 0.006120 | 0.005299 | 9.62 |
| 1m | rudb-native | q5 | 0.000652 | 0.000815 | 0.000179 | 0.008140 | 0.007012 | 10.23 |
| 1m | rudb-native | q6 | 0.000659 | 0.000694 | 0.000069 | 0.007675 | 0.006853 | 9.73 |
| 1m | rudb-native | q7 | 0.001493 | 0.000815 | 0.000086 | 0.007827 | 0.006861 | 10.66 |
| 1m | rudb-native | q8 | 0.001587 | 0.001853 | 0.000148 | 0.009802 | 0.010480 | 15.28 |
| 1m | rudb-native | q9 | 0.006937 | 0.007924 | 0.004172 | 0.017009 | 0.039358 | 48.20 |
| 1m | rudb-native | q10 | 0.037416 | 0.010337 | 0.000208 | 0.021980 | 0.050390 | 53.08 |
| 1m | rudb-native | q11 | 0.003604 | 0.003045 | 0.000565 | 0.010358 | 0.015573 | 25.08 |
| 1m | rudb-native | q12 | 0.002932 | 0.003094 | 0.000475 | 0.010075 | 0.016261 | 25.69 |
| 1m | rudb-native | q13 | 0.003004 | 0.002916 | 0.000297 | 0.010425 | 0.013368 | 17.64 |
| 1m | rudb-native | q14 | 0.005528 | 0.004922 | 0.000125 | 0.012309 | 0.025640 | 32.59 |
| 1m | rudb-native | q15 | 0.004917 | 0.004747 | 0.000376 | 0.012348 | 0.023829 | 26.53 |
| 1m | rudb-native | q16 | 0.000830 | 0.000940 | 0.000181 | 0.007929 | 0.006881 | 11.48 |
| 1m | rudb-native | q17 | 0.008236 | 0.008896 | 0.001656 | 0.016982 | 0.048022 | 53.77 |
| 1m | rudb-native | q18 | 0.001754 | 0.001771 | 0.000093 | 0.008621 | 0.007554 | 12.78 |
| 1m | rudb-native | q19 | 0.012098 | 0.010899 | 0.000909 | 0.019580 | 0.054604 | 57.88 |
| 1m | rudb-native | q20 | 0.001080 | 0.001280 | 0.000150 | 0.008888 | 0.008789 | 13.56 |
| 1m | rudb-native | q21 | 0.018030 | 0.020314 | 0.002156 | 0.030801 | 0.067728 | 46.38 |
| 1m | rudb-native | q22 | 0.023504 | 0.022952 | 0.001259 | 0.033293 | 0.077220 | 52.50 |
| 1m | rudb-native | q23 | 0.021126 | 0.018103 | 0.000954 | 0.027302 | 0.055789 | 44.17 |
| 1m | rudb-native | q24 | 0.020407 | 0.023777 | 0.000402 | 0.034273 | 0.086518 | 65.30 |
| 1m | rudb-native | q25 | 0.002553 | 0.002665 | 0.000133 | 0.012173 | 0.013279 | 16.88 |
| 1m | rudb-native | q26 | 0.003275 | 0.003920 | 0.000018 | 0.013784 | 0.018071 | 18.84 |
| 1m | rudb-native | q27 | 0.003000 | 0.002970 | 0.000089 | 0.011683 | 0.013217 | 17.16 |
| 1m | rudb-native | q28 | 0.005658 | 0.005885 | 0.000874 | 0.015216 | 0.022577 | 31.44 |
| 1m | rudb-native | q29 | 0.057333 | 0.067954 | 0.012286 | 0.078826 | 0.242463 | 81.72 |
| 1m | rudb-native | q30 | 0.004186 | 0.003343 | 0.000071 | 0.010379 | 0.009189 | 12.14 |
| 1m | rudb-native | q31 | 0.004474 | 0.004523 | 0.000531 | 0.012126 | 0.023423 | 29.28 |
| 1m | rudb-native | q32 | 0.001390 | 0.001256 | 0.000036 | 0.008391 | 0.007388 | 11.50 |
| 1m | rudb-native | q33 | 0.001135 | 0.000999 | 0.000055 | 0.008445 | 0.007355 | 11.06 |
| 1m | rudb-native | q34 | 0.001034 | 0.001064 | 0.000707 | 0.009699 | 0.008044 | 11.95 |
| 1m | rudb-native | q35 | 0.004297 | 0.004406 | 0.000250 | 0.012637 | 0.017866 | 24.11 |
| 1m | rudb-native | q36 | 0.001089 | 0.001182 | 0.000068 | 0.008833 | 0.007601 | 10.88 |
| 1m | rudb-native | q37 | 0.002844 | 0.002852 | 0.001004 | 0.011513 | 0.011115 | 16.78 |
| 1m | rudb-native | q38 | 0.002476 | 0.002399 | 0.000143 | 0.010667 | 0.010357 | 15.97 |
| 1m | rudb-native | q39 | 0.001834 | 0.001833 | 0.000200 | 0.009938 | 0.009529 | 15.66 |
| 1m | rudb-native | q40 | 0.004302 | 0.004032 | 0.000139 | 0.011419 | 0.012289 | 19.33 |
| 1m | rudb-native | q41 | 0.001933 | 0.002012 | 0.000169 | 0.010060 | 0.009922 | 15.53 |
| 1m | rudb-native | q42 | 0.001805 | 0.001854 | 0.000059 | 0.009254 | 0.009927 | 15.05 |
| 1m | rudb-native | q43 | 0.002236 | 0.002080 | 0.000368 | 0.009623 | 0.010083 | 15.69 |
| 1m | duckdb-parquet | q1 | 0.002000 | 0.002000 | 0.001000 | 0.019028 | 0.017969 | 19.56 |
| 1m | duckdb-parquet | q2 | 0.003000 | 0.003000 | 0.000000 | 0.020403 | 0.022198 | 22.11 |
| 1m | duckdb-parquet | q3 | 0.002000 | 0.003000 | 0.000000 | 0.021636 | 0.025459 | 23.78 |
| 1m | duckdb-parquet | q4 | 0.004000 | 0.003000 | 0.001000 | 0.021003 | 0.024615 | 35.41 |
| 1m | duckdb-parquet | q5 | 0.016000 | 0.014000 | 0.002000 | 0.037019 | 0.086400 | 69.41 |
| 1m | duckdb-parquet | q6 | 0.011000 | 0.011000 | 0.000000 | 0.032941 | 0.065642 | 58.09 |
| 1m | duckdb-parquet | q7 | 0.004000 | 0.002000 | 0.000000 | 0.026284 | 0.024107 | 22.20 |
| 1m | duckdb-parquet | q8 | 0.004000 | 0.005000 | 0.002000 | 0.029368 | 0.030680 | 23.56 |
| 1m | duckdb-parquet | q9 | 0.030000 | 0.026000 | 0.006000 | 0.051282 | 0.119702 | 78.02 |
| 1m | duckdb-parquet | q10 | 0.059000 | 0.026000 | 0.001000 | 0.049674 | 0.135773 | 84.78 |
| 1m | duckdb-parquet | q11 | 0.012000 | 0.007000 | 0.000000 | 0.031742 | 0.046066 | 54.27 |
| 1m | duckdb-parquet | q12 | 0.007000 | 0.007000 | 0.000000 | 0.028088 | 0.044913 | 54.61 |
| 1m | duckdb-parquet | q13 | 0.013000 | 0.012000 | 0.000000 | 0.033794 | 0.067724 | 61.38 |
| 1m | duckdb-parquet | q14 | 0.020000 | 0.016000 | 0.002000 | 0.037835 | 0.087535 | 84.61 |
| 1m | duckdb-parquet | q15 | 0.012000 | 0.013000 | 0.001000 | 0.034514 | 0.073764 | 65.75 |
| 1m | duckdb-parquet | q16 | 0.017000 | 0.018000 | 0.002000 | 0.039102 | 0.099430 | 78.50 |
| 1m | duckdb-parquet | q17 | 0.036000 | 0.037000 | 0.001000 | 0.061862 | 0.187289 | 157.20 |
| 1m | duckdb-parquet | q18 | 0.030000 | 0.030000 | 0.002000 | 0.052634 | 0.140054 | 142.44 |
| 1m | duckdb-parquet | q19 | 0.044000 | 0.045000 | 0.002000 | 0.073669 | 0.222799 | 184.73 |
| 1m | duckdb-parquet | q20 | 0.003000 | 0.004000 | 0.000000 | 0.028210 | 0.031008 | 35.36 |
| 1m | duckdb-parquet | q21 | 0.038000 | 0.038000 | 0.002000 | 0.066512 | 0.179960 | 141.23 |
| 1m | duckdb-parquet | q22 | 0.042000 | 0.035000 | 0.002000 | 0.064512 | 0.154360 | 158.31 |
| 1m | duckdb-parquet | q23 | 0.071000 | 0.070000 | 0.004000 | 0.096284 | 0.296993 | 275.19 |
| 1m | duckdb-parquet | q24 | 0.109000 | 0.109000 | 0.002000 | 0.140742 | 0.458206 | 412.44 |
| 1m | duckdb-parquet | q25 | 0.020000 | 0.019000 | 0.002000 | 0.047298 | 0.098564 | 60.59 |
| 1m | duckdb-parquet | q26 | 0.009000 | 0.010000 | 0.000000 | 0.034450 | 0.059527 | 37.12 |
| 1m | duckdb-parquet | q27 | 0.014000 | 0.013000 | 0.001000 | 0.038349 | 0.073895 | 49.89 |
| 1m | duckdb-parquet | q28 | 0.032000 | 0.032000 | 0.002000 | 0.058718 | 0.150972 | 159.98 |
| 1m | duckdb-parquet | q29 | 0.261000 | 0.277000 | 0.016000 | 0.311231 | 1.174915 | 183.81 |
| 1m | duckdb-parquet | q30 | 0.009000 | 0.010000 | 0.000000 | 0.033887 | 0.036757 | 34.72 |
| 1m | duckdb-parquet | q31 | 0.015000 | 0.015000 | 0.002000 | 0.038025 | 0.082559 | 62.92 |
| 1m | duckdb-parquet | q32 | 0.015000 | 0.016000 | 0.002000 | 0.038890 | 0.080664 | 71.81 |
| 1m | duckdb-parquet | q33 | 0.037000 | 0.033000 | 0.001000 | 0.059003 | 0.173957 | 125.67 |
| 1m | duckdb-parquet | q34 | 0.071000 | 0.062000 | 0.001000 | 0.089015 | 0.273954 | 278.52 |
| 1m | duckdb-parquet | q35 | 0.060000 | 0.067000 | 0.005000 | 0.095953 | 0.302983 | 286.41 |
| 1m | duckdb-parquet | q36 | 0.023000 | 0.023000 | 0.001000 | 0.049437 | 0.123877 | 78.98 |
| 1m | duckdb-parquet | q37 | 0.017000 | 0.017000 | 0.001000 | 0.041560 | 0.052879 | 68.03 |
| 1m | duckdb-parquet | q38 | 0.021000 | 0.015000 | 0.001000 | 0.038313 | 0.049126 | 62.53 |
| 1m | duckdb-parquet | q39 | 0.014000 | 0.014000 | 0.001000 | 0.036202 | 0.042534 | 67.16 |
| 1m | duckdb-parquet | q40 | 0.026000 | 0.022000 | 0.001000 | 0.044529 | 0.066904 | 101.42 |
| 1m | duckdb-parquet | q41 | 0.005000 | 0.006000 | 0.001000 | 0.029254 | 0.033173 | 35.38 |
| 1m | duckdb-parquet | q42 | 0.004000 | 0.005000 | 0.000000 | 0.028655 | 0.031659 | 32.16 |
| 1m | duckdb-parquet | q43 | 0.005000 | 0.005000 | 0.001000 | 0.027921 | 0.033127 | 32.31 |
| 1m | rudb-parquet | q1 | 0.001630 | 0.001711 | 0.000166 | 0.006709 | 0.006874 | 11.62 |
| 1m | rudb-parquet | q2 | 0.002331 | 0.002297 | 0.000102 | 0.007267 | 0.010374 | 16.80 |
| 1m | rudb-parquet | q3 | 0.002535 | 0.002815 | 0.000039 | 0.008080 | 0.012317 | 20.53 |
| 1m | rudb-parquet | q4 | 0.002684 | 0.002819 | 0.000471 | 0.008032 | 0.012330 | 33.83 |
| 1m | rudb-parquet | q5 | 0.007926 | 0.009365 | 0.001183 | 0.016863 | 0.044007 | 47.34 |
| 1m | rudb-parquet | q6 | 0.018988 | 0.018654 | 0.001263 | 0.024756 | 0.078136 | 52.22 |
| 1m | rudb-parquet | q7 | 0.001031 | 0.001194 | 0.000065 | 0.008205 | 0.007017 | 10.09 |
| 1m | rudb-parquet | q8 | 0.009403 | 0.003565 | 0.000345 | 0.011017 | 0.014171 | 17.84 |
| 1m | rudb-parquet | q9 | 0.014709 | 0.011004 | 0.006330 | 0.020736 | 0.046928 | 59.53 |
| 1m | rudb-parquet | q10 | 0.020068 | 0.013634 | 0.001504 | 0.022165 | 0.060928 | 66.81 |
| 1m | rudb-parquet | q11 | 0.008352 | 0.007379 | 0.000695 | 0.014756 | 0.030727 | 39.64 |
| 1m | rudb-parquet | q12 | 0.007626 | 0.007758 | 0.000835 | 0.014516 | 0.034675 | 44.44 |
| 1m | rudb-parquet | q13 | 0.016356 | 0.015062 | 0.000654 | 0.021298 | 0.065336 | 49.77 |
| 1m | rudb-parquet | q14 | 0.022947 | 0.019339 | 0.000805 | 0.026642 | 0.088616 | 76.23 |
| 1m | rudb-parquet | q15 | 0.034128 | 0.016572 | 0.000792 | 0.023163 | 0.074846 | 54.66 |
| 1m | rudb-parquet | q16 | 0.007012 | 0.007087 | 0.000388 | 0.014167 | 0.032478 | 50.05 |
| 1m | rudb-parquet | q17 | 0.042990 | 0.041490 | 0.002472 | 0.049416 | 0.174549 | 121.59 |
| 1m | rudb-parquet | q18 | 0.015568 | 0.012549 | 0.001722 | 0.019148 | 0.054447 | 49.20 |
| 1m | rudb-parquet | q19 | 0.051580 | 0.052559 | 0.003386 | 0.061019 | 0.219715 | 155.53 |
| 1m | rudb-parquet | q20 | 0.003383 | 0.003327 | 0.000447 | 0.010848 | 0.014512 | 32.09 |
| 1m | rudb-parquet | q21 | 0.046851 | 0.053029 | 0.002556 | 0.064931 | 0.203212 | 170.02 |
| 1m | rudb-parquet | q22 | 0.066900 | 0.058045 | 0.004340 | 0.069701 | 0.222588 | 179.58 |
| 1m | rudb-parquet | q23 | 0.138473 | 0.124772 | 0.006819 | 0.136073 | 0.477691 | 278.88 |
| 1m | rudb-parquet | q24 | 0.111696 | 0.122474 | 0.010415 | 0.138230 | 0.617803 | 332.06 |
| 1m | rudb-parquet | q25 | 0.016357 | 0.014809 | 0.001465 | 0.023787 | 0.058503 | 48.20 |
| 1m | rudb-parquet | q26 | 0.011437 | 0.011272 | 0.000013 | 0.019572 | 0.046061 | 31.86 |
| 1m | rudb-parquet | q27 | 0.014819 | 0.014131 | 0.001961 | 0.022942 | 0.057024 | 49.11 |
| 1m | rudb-parquet | q28 | 0.046417 | 0.046496 | 0.001333 | 0.057706 | 0.187692 | 170.02 |
| 1m | rudb-parquet | q29 | 0.095643 | 0.097662 | 0.010453 | 0.112810 | 0.393840 | 198.09 |
| 1m | rudb-parquet | q30 | 0.006133 | 0.006374 | 0.000259 | 0.013624 | 0.016760 | 18.97 |
| 1m | rudb-parquet | q31 | 0.014675 | 0.013877 | 0.000973 | 0.021407 | 0.059635 | 56.59 |
| 1m | rudb-parquet | q32 | 0.015395 | 0.015077 | 0.000570 | 0.022253 | 0.062482 | 68.88 |
| 1m | rudb-parquet | q33 | 0.012817 | 0.013647 | 0.000947 | 0.021334 | 0.064875 | 70.88 |
| 1m | rudb-parquet | q34 | 0.089636 | 0.081915 | 0.002466 | 0.092775 | 0.356498 | 272.14 |
| 1m | rudb-parquet | q35 | 0.086876 | 0.089106 | 0.004631 | 0.099780 | 0.355092 | 273.52 |
| 1m | rudb-parquet | q36 | 0.006692 | 0.007273 | 0.002232 | 0.014314 | 0.032267 | 39.94 |
| 1m | rudb-parquet | q37 | 0.031055 | 0.031125 | 0.001089 | 0.038531 | 0.055815 | 64.78 |
| 1m | rudb-parquet | q38 | 0.038856 | 0.040237 | 0.001217 | 0.048557 | 0.074496 | 59.64 |
| 1m | rudb-parquet | q39 | 0.027958 | 0.027380 | 0.000857 | 0.033611 | 0.048323 | 63.62 |
| 1m | rudb-parquet | q40 | 0.049598 | 0.048168 | 0.003970 | 0.056632 | 0.092870 | 107.22 |
| 1m | rudb-parquet | q41 | 0.005595 | 0.005199 | 0.000087 | 0.011321 | 0.013642 | 28.48 |
| 1m | rudb-parquet | q42 | 0.004516 | 0.004264 | 0.000526 | 0.011271 | 0.012279 | 26.34 |
| 1m | rudb-parquet | q43 | 0.004858 | 0.005201 | 0.000131 | 0.012039 | 0.014119 | 23.92 |
| 10m | duckdb-native | q1 | 0.003000 | 0.003000 | 0.000000 | 0.033685 | 0.030831 | 21.34 |
| 10m | duckdb-native | q2 | 0.010000 | 0.009000 | 0.000000 | 0.054265 | 0.044794 | 28.53 |
| 10m | duckdb-native | q3 | 0.027000 | 0.017000 | 0.007000 | 0.048995 | 0.083375 | 36.64 |
| 10m | duckdb-native | q4 | 0.034000 | 0.017000 | 0.001000 | 0.054802 | 0.083520 | 42.06 |
| 10m | duckdb-native | q5 | 0.063000 | 0.061000 | 0.016000 | 0.094874 | 0.311226 | 106.55 |
| 10m | duckdb-native | q6 | 0.157000 | 0.143000 | 0.001000 | 0.184342 | 0.540169 | 244.61 |
| 10m | duckdb-native | q7 | 0.005000 | 0.003000 | 0.001000 | 0.033622 | 0.031198 | 22.95 |
| 10m | duckdb-native | q8 | 0.009000 | 0.008000 | 0.000000 | 0.039394 | 0.047382 | 29.61 |
| 10m | duckdb-native | q9 | 0.151000 | 0.147000 | 0.050000 | 0.182170 | 0.395296 | 130.48 |
| 10m | duckdb-native | q10 | 0.278000 | 0.218000 | 0.078000 | 0.252470 | 0.672530 | 146.33 |
| 10m | duckdb-native | q11 | 0.027000 | 0.024000 | 0.002000 | 0.057479 | 0.136208 | 72.94 |
| 10m | duckdb-native | q12 | 0.032000 | 0.034000 | 0.008000 | 0.071448 | 0.154581 | 79.59 |
| 10m | duckdb-native | q13 | 0.177000 | 0.125000 | 0.062000 | 0.223924 | 0.471772 | 254.56 |
| 10m | duckdb-native | q14 | 0.520000 | 0.218000 | 0.074000 | 0.289998 | 0.762789 | 366.11 |
| 10m | duckdb-native | q15 | 0.137000 | 0.103000 | 0.009000 | 0.150684 | 0.506028 | 257.34 |
| 10m | duckdb-native | q16 | 0.129000 | 0.073000 | 0.003000 | 0.107039 | 0.358030 | 120.78 |
| 10m | duckdb-native | q17 | 0.168000 | 0.196000 | 0.023000 | 0.242502 | 0.816760 | 344.03 |
| 10m | duckdb-native | q18 | 0.150000 | 0.152000 | 0.005000 | 0.195595 | 0.691341 | 299.41 |
| 10m | duckdb-native | q19 | 0.401000 | 0.442000 | 0.113000 | 0.533514 | 1.576814 | 692.80 |
| 10m | duckdb-native | q20 | 0.005000 | 0.006000 | 0.001000 | 0.039169 | 0.040477 | 34.14 |
| 10m | duckdb-native | q21 | 0.342000 | 0.192000 | 0.022000 | 0.296287 | 0.833374 | 448.91 |
| 10m | duckdb-native | q22 | 0.149000 | 0.159000 | 0.027000 | 0.249836 | 0.706607 | 499.81 |
| 10m | duckdb-native | q23 | 0.616000 | 0.443000 | 0.111000 | 0.654527 | 1.350447 | 871.73 |
| 10m | duckdb-native | q24 | 0.208000 | 0.174000 | 0.049000 | 0.251836 | 0.735575 | 513.83 |
| 10m | duckdb-native | q25 | 0.012000 | 0.011000 | 0.001000 | 0.036647 | 0.060007 | 40.81 |
| 10m | duckdb-native | q26 | 0.045000 | 0.042000 | 0.002000 | 0.074850 | 0.231857 | 76.16 |
| 10m | duckdb-native | q27 | 0.011000 | 0.011000 | 0.003000 | 0.037919 | 0.056196 | 39.69 |
| 10m | duckdb-native | q28 | 0.140000 | 0.114000 | 0.013000 | 0.181156 | 0.585309 | 458.86 |
| 10m | duckdb-native | q29 | 2.065000 | 2.173000 | 0.391000 | 2.272199 | 9.887006 | 696.36 |
| 10m | duckdb-native | q30 | 0.016000 | 0.015000 | 0.002000 | 0.040951 | 0.067540 | 41.64 |
| 10m | duckdb-native | q31 | 0.082000 | 0.072000 | 0.001000 | 0.103472 | 0.389852 | 190.14 |
| 10m | duckdb-native | q32 | 0.139000 | 0.115000 | 0.010000 | 0.157518 | 0.536056 | 316.97 |
| 10m | duckdb-native | q33 | 0.367000 | 0.411000 | 0.055000 | 0.497991 | 1.775782 | 831.06 |
| 10m | duckdb-native | q34 | 0.473000 | 0.351000 | 0.146000 | 0.464713 | 1.798012 | 1107.84 |
| 10m | duckdb-native | q35 | 0.441000 | 0.503000 | 0.243000 | 0.680913 | 2.143230 | 1155.27 |
| 10m | duckdb-native | q36 | 0.083000 | 0.095000 | 0.018000 | 0.131530 | 0.438413 | 115.66 |
| 10m | duckdb-native | q37 | 0.031000 | 0.043000 | 0.018000 | 0.087538 | 0.159452 | 136.98 |
| 10m | duckdb-native | q38 | 0.017000 | 0.009000 | 0.001000 | 0.039875 | 0.059212 | 47.66 |
| 10m | duckdb-native | q39 | 0.017000 | 0.018000 | 0.006000 | 0.059889 | 0.075437 | 73.22 |
| 10m | duckdb-native | q40 | 0.118000 | 0.064000 | 0.018000 | 0.108095 | 0.301528 | 239.58 |
| 10m | duckdb-native | q41 | 0.010000 | 0.008000 | 0.000000 | 0.038112 | 0.052712 | 46.02 |
| 10m | duckdb-native | q42 | 0.011000 | 0.009000 | 0.003000 | 0.040215 | 0.046797 | 40.92 |
| 10m | duckdb-native | q43 | 0.017000 | 0.011000 | 0.002000 | 0.041234 | 0.057849 | 36.83 |
| 10m | rudb-native | q1 | 0.002093 | 0.001084 | 0.000055 | 0.015676 | 0.013989 | 13.17 |
| 10m | rudb-native | q2 | 0.002427 | 0.001413 | 0.000729 | 0.014645 | 0.012889 | 13.56 |
| 10m | rudb-native | q3 | 0.001231 | 0.001143 | 0.000488 | 0.013661 | 0.011164 | 13.52 |
| 10m | rudb-native | q4 | 0.001223 | 0.000924 | 0.000031 | 0.013733 | 0.011088 | 13.42 |
| 10m | rudb-native | q5 | 0.001234 | 0.001155 | 0.000228 | 0.013536 | 0.011575 | 13.30 |
| 10m | rudb-native | q6 | 0.000978 | 0.000938 | 0.000088 | 0.014857 | 0.012556 | 12.42 |
| 10m | rudb-native | q7 | 0.000926 | 0.001093 | 0.000086 | 0.015980 | 0.013494 | 12.44 |
| 10m | rudb-native | q8 | 0.007752 | 0.004233 | 0.000264 | 0.020375 | 0.028843 | 20.14 |
| 10m | rudb-native | q9 | 0.038372 | 0.029276 | 0.008723 | 0.049121 | 0.130317 | 73.72 |
| 10m | rudb-native | q10 | 0.037478 | 0.033216 | 0.000959 | 0.050759 | 0.176243 | 82.75 |
| 10m | rudb-native | q11 | 0.009414 | 0.009247 | 0.000759 | 0.025118 | 0.054159 | 36.56 |
| 10m | rudb-native | q12 | 0.010584 | 0.011753 | 0.001752 | 0.028378 | 0.060592 | 37.67 |
| 10m | rudb-native | q13 | 0.018294 | 0.011109 | 0.000466 | 0.026665 | 0.054207 | 38.05 |
| 10m | rudb-native | q14 | 0.029047 | 0.028898 | 0.019804 | 0.047177 | 0.141159 | 83.06 |
| 10m | rudb-native | q15 | 0.028150 | 0.024528 | 0.001204 | 0.042757 | 0.123939 | 80.70 |
| 10m | rudb-native | q16 | 0.001512 | 0.001100 | 0.000348 | 0.012732 | 0.010069 | 12.92 |
| 10m | rudb-native | q17 | 0.041001 | 0.051825 | 0.009868 | 0.071663 | 0.219235 | 128.91 |
| 10m | rudb-native | q18 | 0.004959 | 0.004469 | 0.001307 | 0.018242 | 0.016469 | 22.47 |
| 10m | rudb-native | q19 | 0.087378 | 0.082215 | 0.012382 | 0.105088 | 0.401643 | 232.66 |
| 10m | rudb-native | q20 | 0.003295 | 0.002027 | 0.000372 | 0.018418 | 0.014685 | 15.94 |
| 10m | rudb-native | q21 | 0.106721 | 0.045499 | 0.007269 | 0.060817 | 0.204256 | 67.89 |
| 10m | rudb-native | q22 | 0.067195 | 0.061479 | 0.011679 | 0.092997 | 0.233436 | 88.77 |
| 10m | rudb-native | q23 | 0.210734 | 0.106964 | 0.005263 | 0.123471 | 0.401656 | 149.47 |
| 10m | rudb-native | q24 | 0.082193 | 0.052733 | 0.001240 | 0.069038 | 0.199920 | 99.14 |
| 10m | rudb-native | q25 | 0.005132 | 0.004257 | 0.000146 | 0.016979 | 0.018460 | 21.45 |
| 10m | rudb-native | q26 | 0.029669 | 0.015027 | 0.001720 | 0.028942 | 0.058338 | 35.45 |
| 10m | rudb-native | q27 | 0.011384 | 0.008151 | 0.000642 | 0.019863 | 0.021701 | 24.39 |
| 10m | rudb-native | q28 | 0.036699 | 0.024805 | 0.002304 | 0.040310 | 0.103990 | 69.08 |
| 10m | rudb-native | q29 | 0.472330 | 0.411955 | 0.154437 | 0.433685 | 1.701369 | 282.28 |
| 10m | rudb-native | q30 | 0.004142 | 0.004169 | 0.000677 | 0.014308 | 0.012981 | 14.17 |
| 10m | rudb-native | q31 | 0.054703 | 0.032932 | 0.004419 | 0.045884 | 0.164454 | 94.64 |
| 10m | rudb-native | q32 | 0.002112 | 0.001923 | 0.000170 | 0.012744 | 0.011463 | 15.19 |
| 10m | rudb-native | q33 | 0.001425 | 0.001416 | 0.000040 | 0.013472 | 0.011816 | 13.30 |
| 10m | rudb-native | q34 | 0.001468 | 0.001224 | 0.000127 | 0.012707 | 0.011522 | 13.42 |
| 10m | rudb-native | q35 | 0.040620 | 0.025232 | 0.002098 | 0.040411 | 0.108327 | 96.72 |
| 10m | rudb-native | q36 | 0.001884 | 0.001496 | 0.000175 | 0.013822 | 0.011988 | 13.73 |
| 10m | rudb-native | q37 | 0.011161 | 0.009481 | 0.000111 | 0.023933 | 0.032175 | 42.30 |
| 10m | rudb-native | q38 | 0.049149 | 0.008043 | 0.001026 | 0.021923 | 0.030369 | 35.91 |
| 10m | rudb-native | q39 | 0.009080 | 0.007290 | 0.001652 | 0.021199 | 0.022743 | 28.42 |
| 10m | rudb-native | q40 | 0.039213 | 0.046425 | 0.004095 | 0.059759 | 0.156731 | 89.83 |
| 10m | rudb-native | q41 | 0.014300 | 0.008667 | 0.003614 | 0.024160 | 0.033308 | 40.34 |
| 10m | rudb-native | q42 | 0.012339 | 0.009043 | 0.001158 | 0.023560 | 0.026373 | 31.61 |
| 10m | rudb-native | q43 | 0.010385 | 0.007349 | 0.001509 | 0.021023 | 0.028868 | 27.61 |
| 10m | duckdb-parquet | q1 | 0.023000 | 0.025000 | 0.001000 | 0.069119 | 0.064221 | 36.94 |
| 10m | duckdb-parquet | q2 | 0.068000 | 0.044000 | 0.003000 | 0.111564 | 0.105752 | 35.91 |
| 10m | duckdb-parquet | q3 | 0.065000 | 0.047000 | 0.044000 | 0.134751 | 0.132394 | 42.64 |
| 10m | duckdb-parquet | q4 | 0.059000 | 0.044000 | 0.007000 | 0.090599 | 0.130302 | 57.94 |
| 10m | duckdb-parquet | q5 | 0.112000 | 0.073000 | 0.019000 | 0.121857 | 0.291698 | 116.36 |
| 10m | duckdb-parquet | q6 | 0.227000 | 0.160000 | 0.029000 | 0.206537 | 0.627330 | 252.48 |
| 10m | duckdb-parquet | q7 | 0.021000 | 0.023000 | 0.007000 | 0.068103 | 0.065970 | 37.67 |
| 10m | duckdb-parquet | q8 | 0.031000 | 0.036000 | 0.006000 | 0.084648 | 0.107943 | 39.30 |
| 10m | duckdb-parquet | q9 | 0.204000 | 0.175000 | 0.056000 | 0.222841 | 0.438601 | 128.81 |
| 10m | duckdb-parquet | q10 | 0.280000 | 0.275000 | 0.067000 | 0.331038 | 0.660149 | 138.31 |
| 10m | duckdb-parquet | q11 | 0.053000 | 0.052000 | 0.006000 | 0.100227 | 0.182672 | 75.22 |
| 10m | duckdb-parquet | q12 | 0.077000 | 0.069000 | 0.013000 | 0.122173 | 0.204913 | 75.94 |
| 10m | duckdb-parquet | q13 | 0.343000 | 0.358000 | 0.075000 | 0.416856 | 0.656525 | 251.28 |
| 10m | duckdb-parquet | q14 | 0.450000 | 0.373000 | 0.123000 | 0.448343 | 0.943067 | 345.25 |
| 10m | duckdb-parquet | q15 | 0.164000 | 0.172000 | 0.009000 | 0.225016 | 0.711488 | 263.42 |
| 10m | duckdb-parquet | q16 | 0.081000 | 0.082000 | 0.019000 | 0.127506 | 0.342197 | 132.45 |
| 10m | duckdb-parquet | q17 | 0.251000 | 0.322000 | 0.061000 | 0.376217 | 1.049062 | 333.70 |
| 10m | duckdb-parquet | q18 | 0.289000 | 0.206000 | 0.014000 | 0.254203 | 0.844306 | 311.19 |
| 10m | duckdb-parquet | q19 | 0.357000 | 0.410000 | 0.053000 | 0.476012 | 1.745930 | 661.22 |
| 10m | duckdb-parquet | q20 | 0.033000 | 0.028000 | 0.005000 | 0.078799 | 0.080525 | 50.67 |
| 10m | duckdb-parquet | q21 | 0.323000 | 0.284000 | 0.043000 | 0.346877 | 1.187271 | 306.89 |
| 10m | duckdb-parquet | q22 | 0.202000 | 0.274000 | 0.110000 | 0.329253 | 1.055381 | 412.20 |
| 10m | duckdb-parquet | q23 | 0.568000 | 0.515000 | 0.083000 | 0.568308 | 2.119194 | 644.17 |
| 10m | duckdb-parquet | q24 | 0.466000 | 0.333000 | 0.022000 | 0.387948 | 1.389408 | 466.89 |
| 10m | duckdb-parquet | q25 | 0.076000 | 0.088000 | 0.001000 | 0.127999 | 0.311348 | 110.48 |
| 10m | duckdb-parquet | q26 | 0.103000 | 0.098000 | 0.023000 | 0.140021 | 0.414230 | 99.45 |
| 10m | duckdb-parquet | q27 | 0.075000 | 0.072000 | 0.009000 | 0.115153 | 0.300673 | 111.91 |
| 10m | duckdb-parquet | q28 | 0.313000 | 0.209000 | 0.017000 | 0.256097 | 0.969927 | 399.89 |
| 10m | duckdb-parquet | q29 | 2.839000 | 3.107000 | 0.340000 | 3.192919 | 12.451727 | 593.09 |
| 10m | duckdb-parquet | q30 | 0.038000 | 0.033000 | 0.001000 | 0.069385 | 0.097023 | 51.52 |
| 10m | duckdb-parquet | q31 | 0.128000 | 0.124000 | 0.009000 | 0.163880 | 0.609136 | 175.38 |
| 10m | duckdb-parquet | q32 | 0.154000 | 0.163000 | 0.007000 | 0.205985 | 0.711282 | 235.70 |
| 10m | duckdb-parquet | q33 | 0.417000 | 0.392000 | 0.052000 | 0.453782 | 1.793687 | 735.69 |
| 10m | duckdb-parquet | q34 | 0.470000 | 0.473000 | 0.101000 | 0.533177 | 2.142809 | 942.94 |
| 10m | duckdb-parquet | q35 | 0.570000 | 0.608000 | 0.107000 | 0.686655 | 2.357882 | 988.05 |
| 10m | duckdb-parquet | q36 | 0.147000 | 0.114000 | 0.049000 | 0.157249 | 0.487522 | 120.42 |
| 10m | duckdb-parquet | q37 | 0.099000 | 0.084000 | 0.012000 | 0.132850 | 0.257556 | 205.17 |
| 10m | duckdb-parquet | q38 | 0.033000 | 0.036000 | 0.002000 | 0.079553 | 0.106665 | 58.34 |
| 10m | duckdb-parquet | q39 | 0.058000 | 0.056000 | 0.011000 | 0.106524 | 0.152058 | 141.59 |
| 10m | duckdb-parquet | q40 | 0.182000 | 0.134000 | 0.015000 | 0.184211 | 0.416797 | 318.92 |
| 10m | duckdb-parquet | q41 | 0.031000 | 0.033000 | 0.004000 | 0.077296 | 0.097940 | 62.61 |
| 10m | duckdb-parquet | q42 | 0.031000 | 0.034000 | 0.000000 | 0.078130 | 0.092036 | 55.69 |
| 10m | duckdb-parquet | q43 | 0.043000 | 0.044000 | 0.008000 | 0.086489 | 0.113464 | 52.70 |
| 10m | rudb-parquet | q1 | 0.018657 | 0.016122 | 0.000741 | 0.025118 | 0.024595 | 23.88 |
| 10m | rudb-parquet | q2 | 0.025561 | 0.032823 | 0.011682 | 0.045235 | 0.070286 | 32.45 |
| 10m | rudb-parquet | q3 | 0.049355 | 0.030130 | 0.016253 | 0.041668 | 0.074010 | 39.52 |
| 10m | rudb-parquet | q4 | 0.029134 | 0.025455 | 0.004892 | 0.034453 | 0.079690 | 52.48 |
| 10m | rudb-parquet | q5 | 0.115786 | 0.085149 | 0.014568 | 0.097893 | 0.310746 | 154.30 |
| 10m | rudb-parquet | q6 | 0.261814 | 0.301242 | 0.152539 | 0.319709 | 0.867218 | 210.42 |
| 10m | rudb-parquet | q7 | 0.012084 | 0.007575 | 0.000504 | 0.018631 | 0.016413 | 16.75 |
| 10m | rudb-parquet | q8 | 0.028373 | 0.025063 | 0.001432 | 0.036735 | 0.074254 | 30.84 |
| 10m | rudb-parquet | q9 | 0.069873 | 0.054076 | 0.001606 | 0.066132 | 0.211373 | 85.14 |
| 10m | rudb-parquet | q10 | 0.127364 | 0.075640 | 0.006921 | 0.088856 | 0.325354 | 97.36 |
| 10m | rudb-parquet | q11 | 0.058741 | 0.052694 | 0.002489 | 0.066321 | 0.216756 | 58.09 |
| 10m | rudb-parquet | q12 | 0.083318 | 0.076258 | 0.017948 | 0.088125 | 0.248400 | 63.47 |
| 10m | rudb-parquet | q13 | 0.365441 | 0.317354 | 0.093540 | 0.335773 | 0.762967 | 206.08 |
| 10m | rudb-parquet | q14 | 0.710575 | 0.358005 | 0.201391 | 0.376441 | 1.000436 | 295.31 |
| 10m | rudb-parquet | q15 | 0.356248 | 0.246085 | 0.078704 | 0.263688 | 0.851064 | 223.31 |
| 10m | rudb-parquet | q16 | 0.036839 | 0.046494 | 0.014604 | 0.057785 | 0.144863 | 80.53 |
| 10m | rudb-parquet | q17 | 0.394971 | 0.446334 | 0.112535 | 0.467136 | 1.316941 | 364.27 |
| 10m | rudb-parquet | q18 | 0.138892 | 0.129483 | 0.016168 | 0.141859 | 0.564845 | 127.47 |
| 10m | rudb-parquet | q19 | 0.587627 | 0.534156 | 0.101781 | 0.570368 | 2.131532 | 671.81 |
| 10m | rudb-parquet | q20 | 0.023354 | 0.023008 | 0.001835 | 0.036118 | 0.050187 | 45.70 |
| 10m | rudb-parquet | q21 | 0.413825 | 0.355197 | 0.077972 | 0.372340 | 1.437208 | 296.78 |
| 10m | rudb-parquet | q22 | 0.449968 | 0.411817 | 0.041580 | 0.433397 | 1.719946 | 372.86 |
| 10m | rudb-parquet | q23 | 1.060772 | 1.052045 | 0.126618 | 1.069197 | 3.990358 | 483.88 |
| 10m | rudb-parquet | q24 | 0.474873 | 0.454008 | 0.014963 | 0.472667 | 2.071301 | 373.75 |
| 10m | rudb-parquet | q25 | 0.112158 | 0.131290 | 0.021573 | 0.143608 | 0.564058 | 156.16 |
| 10m | rudb-parquet | q26 | 0.106921 | 0.117744 | 0.025013 | 0.129810 | 0.444976 | 142.44 |
| 10m | rudb-parquet | q27 | 0.129710 | 0.125663 | 0.016794 | 0.138448 | 0.569144 | 160.80 |
| 10m | rudb-parquet | q28 | 0.432515 | 0.271700 | 0.005701 | 0.286298 | 1.293016 | 305.19 |
| 10m | rudb-parquet | q29 | 1.104074 | 0.841593 | 0.087158 | 0.868011 | 3.581872 | 743.25 |
| 10m | rudb-parquet | q30 | 0.021212 | 0.020920 | 0.001867 | 0.028918 | 0.053359 | 31.83 |
| 10m | rudb-parquet | q31 | 0.130682 | 0.120106 | 0.000904 | 0.129802 | 0.594403 | 150.11 |
| 10m | rudb-parquet | q32 | 0.128342 | 0.136407 | 0.013239 | 0.146813 | 0.625246 | 177.52 |
| 10m | rudb-parquet | q33 | 0.106891 | 0.106631 | 0.003848 | 0.120583 | 0.533999 | 243.38 |
| 10m | rudb-parquet | q34 | 0.719967 | 0.662408 | 0.149523 | 0.697712 | 3.009663 | 795.08 |
| 10m | rudb-parquet | q35 | 0.580055 | 0.766567 | 0.084789 | 0.791875 | 3.025135 | 783.83 |
| 10m | rudb-parquet | q36 | 0.035458 | 0.042034 | 0.009400 | 0.054304 | 0.135755 | 71.53 |
| 10m | rudb-parquet | q37 | 0.078248 | 0.101136 | 0.051397 | 0.118965 | 0.257984 | 192.02 |
| 10m | rudb-parquet | q38 | 0.045813 | 0.046970 | 0.006555 | 0.059494 | 0.110329 | 60.09 |
| 10m | rudb-parquet | q39 | 0.058769 | 0.056765 | 0.008664 | 0.072080 | 0.152453 | 145.94 |
| 10m | rudb-parquet | q40 | 0.179054 | 0.169625 | 0.012825 | 0.185753 | 0.592309 | 345.48 |
| 10m | rudb-parquet | q41 | 0.022368 | 0.026817 | 0.003251 | 0.036726 | 0.064376 | 67.02 |
| 10m | rudb-parquet | q42 | 0.021839 | 0.030508 | 0.016235 | 0.042749 | 0.052633 | 57.25 |
| 10m | rudb-parquet | q43 | 0.041139 | 0.034178 | 0.007603 | 0.043320 | 0.068495 | 54.81 |
