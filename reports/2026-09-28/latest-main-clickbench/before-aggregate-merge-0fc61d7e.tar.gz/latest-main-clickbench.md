# Latest main ClickBench rerun, 2026-09-28

RuDB was rebased onto main `0fc61d7e8ed5fc35f636e3148a31532015285bdb` and rebuilt before this run. The measured binary stayed fixed throughout. DuckDB is the released v1.5.5 build `d8cdaa33fd`. These results are a new baseline, not an improvement comparison against earlier reports taken on other hosts or revisions.

At 10m rows, the sum of per-query process-wall medians is 9.437 seconds for DuckDB native and 1.854 seconds for RuDB native, a 5.09x ratio. For Parquet it is 12.546 seconds and 9.621 seconds, a 1.30x ratio. The 10x time and memory goal is not met across the suite.

## Measurement protocol

All 43 canonical ClickBench queries ran on the same 1k, 10k, 1m, and 10m samples in four cases: DuckDB native, RuDB native, DuckDB Parquet, and RuDB Parquet. There are 4,128 successful timed query executions and eight native loads. Each query has one first execution and five subsequent repetitions. Every repetition starts a fresh process, and the four cases rotate order on each query and repetition. The OS page cache is not flushed. These are warm-cache sample measurements, not official ClickBench scores.

Both engines receive `SET threads=6; SET memory_limit='4GB'` for loads and queries. Every RuDB query also receives `SET stored_answers=false`, and every measured child receives `RUDB_PARQUET_MIRROR=0`. The settings are read back and retained in the metadata. Native files were loaded afresh using the same `CREATE TABLE`, `INSERT INTO ... SELECT * FROM read_parquet(...)`, and `CHECKPOINT` SQL. The samples already contain typed DATE and TIMESTAMP columns, so both engines use an identity projection. No optional projection or index was built after the native load.

Reusable column statistics remain enabled. Some scalar queries can therefore use native metadata rather than scan rows. The current writer does not save pair leaders or derived host-group query results, and the reader ignores legacy results of those kinds. The table below also gives totals excluding Q1 through Q7 so their scalar shapes do not hide the rest of the workload. This exclusion is a sensitivity check, not proof that every other query scans rows.

Process wall time is measured with a monotonic clock around the native child. CPU is user plus system time, and peak RSS comes from `wait4` for that exact child. The macOS RSS reading is already in bytes; Linux converts KiB to bytes. macOS I/O byte readings are unavailable and stored as null. The CLI query timer, including result rendering, is retained separately. Headline totals sum the five-repetition median for each query, including process startup. Peak RSS in the summary is the largest observed query-process peak, not a sum, allocation count, or average.

The host is an Apple M4 Mac16,13 with 10 hardware threads and 24 GiB RAM, running macOS 15.8.1. It was shared with other work and had substantial existing swap use. Per-execution load averages and timing spread are retained. Rotating order reduces ordering bias, but these results do not establish quiet-host latency. Loads have one observation each.

## Query comparison

| Rows | Format | DuckDB wall total (s) | RuDB wall total (s) | DuckDB / RuDB wall | DuckDB CPU total (s) | RuDB CPU total (s) | DuckDB max RSS (MiB) | RuDB max RSS (MiB) | DuckDB / RuDB max RSS |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1k | native | 0.887 | 0.290 | 3.06x | 0.893 | 0.248 | 35.72 | 12.84 | 2.78x |
| 1k | parquet | 0.897 | 0.281 | 3.19x | 0.904 | 0.240 | 33.03 | 11.55 | 2.86x |
| 10k | native | 0.929 | 0.328 | 2.83x | 0.951 | 0.284 | 37.66 | 13.91 | 2.71x |
| 10k | parquet | 0.951 | 0.319 | 2.98x | 0.969 | 0.276 | 38.62 | 13.95 | 2.77x |
| 1m | native | 1.917 | 0.615 | 3.12x | 4.644 | 1.114 | 269.86 | 81.72 | 3.30x |
| 1m | parquet | 2.239 | 1.532 | 1.46x | 5.585 | 4.607 | 412.44 | 332.06 | 1.24x |
| 10m | native | 9.437 | 1.854 | 5.09x | 30.103 | 5.125 | 1155.27 | 282.28 | 4.09x |
| 10m | parquet | 12.546 | 9.621 | 1.30x | 39.020 | 34.290 | 988.05 | 795.08 | 1.24x |

All cases completed the same 43 queries. A ratio above one favors RuDB. Ratios of totals are different from the geometric mean of query ratios.

| Rows | Format | DuckDB Q8–Q43 wall total (s) | RuDB Q8–Q43 wall total (s) | DuckDB / RuDB wall |
| --- | --- | ---: | ---: | ---: |
| 1k | native | 0.760 | 0.248 | 3.06x |
| 1k | parquet | 0.765 | 0.240 | 3.19x |
| 10k | native | 0.789 | 0.281 | 2.81x |
| 10k | parquet | 0.807 | 0.274 | 2.95x |
| 1m | native | 1.749 | 0.567 | 3.09x |
| 1m | parquet | 2.061 | 1.452 | 1.42x |
| 10m | native | 8.933 | 1.752 | 5.10x |
| 10m | parquet | 11.744 | 9.038 | 1.30x |

For the query-level target, both wall and RSS use medians of the five subsequent fresh processes. The counts below cover timed performance only. Original tied row selections remain qualified by the correctness checks.

| Rows | Format | Wall-ratio geometric mean | Queries at least 10x faster / 43 | Queries with at least 10x lower RSS / 43 | Queries meeting both / 43 |
| --- | --- | ---: | ---: | ---: | ---: |
| 1k | native | 3.06x | 0 | 0 | 0 |
| 1k | parquet | 3.19x | 0 | 0 | 0 |
| 10k | native | 2.86x | 0 | 0 | 0 |
| 10k | parquet | 2.99x | 0 | 0 | 0 |
| 1m | native | 3.10x | 0 | 3 | 0 |
| 1m | parquet | 1.75x | 0 | 0 | 0 |
| 10m | native | 4.18x | 6 | 6 | 6 |
| 10m | parquet | 1.49x | 0 | 0 | 0 |

## Native load cost

| Rows | Engine | Load wall (s) | Load CPU (s) | Load peak RSS (MiB) | Native file (MiB) |
| --- | --- | ---: | ---: | ---: | ---: |
| 1k | duckdb-native | 0.069 | 0.095 | 67.91 | 1.01 |
| 1k | rudb-native | 0.135 | 0.122 | 38.19 | 1.79 |
| 10k | duckdb-native | 0.135 | 0.136 | 58.55 | 4.26 |
| 10k | rudb-native | 0.429 | 0.484 | 71.53 | 7.37 |
| 1m | duckdb-native | 5.046 | 14.145 | 1297.64 | 426.76 |
| 1m | rudb-native | 2.967 | 10.868 | 1479.52 | 235.18 |
| 10m | duckdb-native | 63.946 | 97.942 | 2287.05 | 2259.26 |
| 10m | rudb-native | 58.089 | 89.541 | 1405.91 | 1400.15 |

Load memory is reported separately from query memory. Native metadata construction is included in the RuDB load.

## Answer checks

Every retained output was checked across all four cases and all six repetitions, using exact integer comparisons and a 1e-9 tolerance for floating point. Q29 at 10m matches on all 24 original executions.

| Rows | Original answers match | Same rows, different order | Different selection, deterministic retest matches | Failed or unresolved |
| --- | ---: | ---: | ---: | ---: |
| 1k | 24 | 6 | 13 | 0 |
| 10k | 25 | 3 | 15 | 0 |
| 1m | 27 | 8 | 8 | 0 |
| 10m | 32 | 4 | 7 | 0 |

Of 172 size/query combinations, 108 original outputs match and 21 contain the same rows in a different order. The remaining 43 select different rows. All 43 match after adding deterministic output-column tie breakers in separate untimed queries. The original SQL, outputs, and differences remain intact. A matching diagnostic does not prove that each originally selected row was correct; no blanket claim of identical original answers is made.

## Remaining performance gaps at 10m

This run gives a baseline for profiling, not a new root-cause diagnosis. The native comparison has six queries meeting both 10x targets; Parquet has none. The weakest wall ratios below show where the goal is still furthest away.

| Format | Query | DuckDB wall (ms) | RuDB wall (ms) | DuckDB / RuDB wall | DuckDB median RSS (MiB) | RuDB median RSS (MiB) |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| native | Q41 | 38.112 | 24.160 | 1.58x | 45.34 | 39.23 |
| native | Q42 | 40.215 | 23.560 | 1.71x | 40.27 | 31.23 |
| native | Q40 | 108.095 | 59.759 | 1.81x | 233.03 | 88.00 |
| native | Q38 | 39.875 | 21.923 | 1.82x | 47.41 | 35.00 |
| native | Q27 | 37.919 | 19.863 | 1.91x | 37.19 | 24.05 |
| native | Q8 | 39.394 | 20.375 | 1.93x | 29.39 | 20.08 |
| native | Q43 | 41.234 | 21.023 | 1.96x | 35.48 | 26.86 |
| parquet | Q23 | 568.308 | 1069.197 | 0.53x | 612.08 | 454.56 |
| parquet | Q6 | 206.537 | 319.709 | 0.65x | 247.48 | 203.89 |
| parquet | Q22 | 329.253 | 433.397 | 0.76x | 396.31 | 348.92 |
| parquet | Q34 | 533.177 | 697.712 | 0.76x | 932.56 | 788.38 |
| parquet | Q17 | 376.217 | 467.136 | 0.81x | 326.09 | 353.02 |
| parquet | Q24 | 387.948 | 472.667 | 0.82x | 451.39 | 353.41 |
| parquet | Q27 | 115.153 | 138.448 | 0.83x | 111.00 | 152.69 |

Q9 here opens the ordinary freshly loaded native table. It is not the optional indexed Q9 experiment in the earlier reports.

## Reproduce and inspect

The [per-query tables](latest-main-clickbench/per-query.md), [raw repetitions](latest-main-clickbench/raw.jsonl.gz), [correctness results](latest-main-clickbench/correctness.json), [metadata](latest-main-clickbench/metadata.json), and [provenance](latest-main-clickbench/provenance.json) retain the measurements. The [output archive](latest-main-clickbench/outputs.tar.gz) contains every original CSV, stderr, resource record, SQL file, deterministic diagnostic, and the measured script snapshots. Native databases and source Parquet files are excluded from the archive. Their local paths and source hashes are recorded.

The first run allowed RuDB's default Parquet mirroring, which writes and reuses a native file for sufficiently large Parquet inputs. Its 10m RuDB Parquet case is not a pure Parquet comparison. That run is withdrawn as a four-way comparison and excluded from every table above. Its [diagnostic archive](latest-main-clickbench/mirror-diagnostic.tar.gz) is retained with a warning. The corrected run rebuilt all native files in a new directory and explicitly disabled mirroring for every measured child.

The harness tests passed on macOS and Linux, including per-child RSS, child failures, timeouts, exact large integers, and the mirroring environment override. The benchmark Rust suite passed 395 library, 23 binary, four integration, and one additional test; strict all-target Clippy passed. No engine source changes were made for this rerun.

```sh
cc -O2 -Wall -Wextra -Werror scripts/measure-child.c -o scripts/measure-child
cargo run --release --example export_clickbench -- "$OUTPUT/sql"
# For these already typed samples, set projection.sql to a single *.
printf "*\n" > "$OUTPUT/sql/projection.sql"
python3 scripts/clickbench-audit.py \
  --duckdb "$DUCKDB" --rudb "$RUDB" --data "$DATA" --output "$OUTPUT" \
  --sizes 1k 10k 1m 10m --hot 5 --threads 6 --memory-limit 4GB --timeout 600
python3 scripts/verify-clickbench-audit.py "$OUTPUT"
```

Use a new output directory and the exact source samples. Upstream raw integer date/time files require the exported normalization projection instead of this identity projection. Binary and source SHA-256 values are in the metadata. RuDB executable SHA-256 is `123aa5687d3ed29a8ae1fb10b67ffb74a37325e94ad6fd96b967e6b31174f1bd`. The benchmark base revision is `0f2b0af5817fef1c4417a98909e09327bb1df675`, with the script changes in this report's PR.
