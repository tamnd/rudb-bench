import collections
import gzip
import hashlib
import json
from pathlib import Path
import statistics
import sys
import tarfile

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=True)
raw = [json.loads(line) for line in (root / 'raw.jsonl').read_text().splitlines()]
meta = json.loads((root / 'metadata.json').read_text())
checks = json.loads((root / 'correctness.json').read_text())
sizes = ['1k', '10k', '1m', '10m']
engines = ['duckdb-native', 'rudb-native', 'duckdb-parquet', 'rudb-parquet']
queries = [r for r in raw if r['phase'] == 'query']
loads = [r for r in raw if r['phase'] == 'load']
assert len(queries) == 5504 and len(loads) == 8
assert all(r['status'] == 'ok' and r['exit_code'] == 0 for r in raw)
assert all(r['wall_s'] > 0 and r['peak_rss_bytes'] > 0 for r in raw)
assert len(checks) == 172
allowed = {'original match', 'same rows; different order', 'original selections differ; deterministic retest match'}
assert all(c['result'] in allowed for c in checks), collections.Counter(c['result'] for c in checks)
groups = {}
for size in sizes:
    for engine in engines:
        for q in range(1, 44):
            rows = [r for r in queries if (r['size'], r['engine'], r['query']) == (size, engine, q)]
            assert sorted(r['run'] for r in rows) == list(range(8))
            hot = [r for r in rows if r['run'] > 0]
            groups[size, engine, q] = dict(wall=statistics.median(r['wall_s'] for r in hot),
                cpu=statistics.median(r['cpu_s'] for r in hot),
                rss=max(r['peak_rss_bytes'] for r in rows),
                median_rss=statistics.median(r['peak_rss_bytes'] for r in hot))

def totals(size, engine, start=1):
    items = [groups[size, engine, q] for q in range(start, 44)]
    return dict(wall=sum(r['wall'] for r in items), cpu=sum(r['cpu'] for r in items), rss=max(r['rss'] for r in items))

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

for name in ['metadata.json', 'correctness.json', 'summary.json']:
    (out / name).write_bytes((root / name).read_bytes())
(out / 'per-query.md').write_bytes((root / 'report.md').read_bytes())
with gzip.GzipFile(filename=str(out / 'raw.jsonl.gz'), mode='wb', mtime=0) as f:
    f.write((root / 'raw.jsonl').read_bytes())
native = {}
for size in sizes:
    for suffix in ['duckdb', 'rudb']:
        path = root / f'{size}.{suffix}'
        native[path.name] = dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))
(out / 'native-files.json').write_text(json.dumps(native, indent=2) + '\n')
with tarfile.open(out / 'outputs.tar.gz', 'w:gz') as tar:
    for path in sorted(root.rglob('*')):
        if not path.is_file():
            continue
        if path.suffix in {'.stdout', '.stderr', '.sql', '.caveat', '.py', '.c', '.log'} or path.name.endswith('.resource.json'):
            tar.add(path, arcname=str(path.relative_to(root)))

before = [r['load_before'][0] for r in raw]
after = [r['load_after'][0] for r in raw]
if meta['max_load'] is not None:
    assert max(before) <= meta['max_load']
asset = out.name
lines = ['# ClickBench rerun at main 6a89e090', '',
    'RuDB was rebuilt from clean main `6a89e090e227ab62864ed26952ed5a84ae63a0f8`, version 0.8.4. DuckDB is the released v1.5.5 build `d8cdaa33fd`. Both executables stayed fixed throughout the run. The pending topology, Parquet schema index, and bound-reader changes were rebased onto this main revision but are not included in the measured binary.', '',
    'All 43 canonical queries completed at 1k, 10k, 1m, and 10m in four cases: DuckDB native, RuDB native, DuckDB Parquet, and RuDB Parquet. This run has 5,504 successful timed query children and eight native loads. The target of 10x faster queries and 10x less memory remains unproven.', '',
    '## Measurement protocol', '',
    'Every execution starts a fresh process. One first execution is retained separately, followed by seven fresh-process repetitions whose medians form the tables. The OS page cache is not flushed. Neighboring rounds reverse execution order and rotate after each pair. The eight rounds balance positions and which engine runs first; excluding the first round leaves a small order imbalance in the seven-observation medians.', '',
    'Both engines use six threads and a 4GB memory limit. RuDB uses `SET stored_answers=false`; measured children receive `RUDB_PARQUET_MIRROR=0`. Ordinary reusable column statistics remain enabled. No query-specific result or optional index was introduced. Native files were loaded afresh using identical explicit schema, `INSERT INTO hits SELECT ... FROM read_parquet(...)`, and `CHECKPOINT` SQL. The same normalization projection converts raw integer dates and timestamps in both engines. Parquet cases read the same source file.', '',
    'A monotonic clock measures the whole child process, including startup, file opening, parsing, execution, rendering, and exit. User plus system CPU and peak RSS come from wait4 for that child. Linux RSS is converted from KiB to bytes. Peak RSS measures resident memory, not allocated bytes or an incremental delta. Rounded CLI query timers are retained but do not drive headline ratios. Totals sum per-query medians. Maximum RSS is the largest peak among all observations, not a sum.', '',
    f'The shared Linux Hyper-V host exposes 32 logical CPUs on an Intel Core i9-13900K and about 31 GiB RAM. The harness waits before each load and query child until one-minute load is at most 8, with a 600-second capacity timeout. Pre-child load ranged from {min(before):.2f} to {max(before):.2f}; post-child load ranged from {min(after):.2f} to {max(after):.2f}. The gate does not provide exclusive CPUs or stable clocks. Load, waiting time, context switches, faults, CPU, stdout, and stderr are retained. These measurements compare the engines within this run; differences from earlier runs cannot be attributed to commits without an interleaved comparison.', '',
    'The 1m and 10m samples contain 999,975 and 9,999,750 rows. Source files are the same Linux samples used in the preceding main-998cc427 report. Actual row counts and hashes are recorded.', '',
    '## Query comparison', '',
    '| Sample | Format | DuckDB wall total (s) | RuDB wall total (s) | DuckDB / RuDB wall | DuckDB CPU total (s) | RuDB CPU total (s) | DuckDB max RSS (MiB) | RuDB max RSS (MiB) | DuckDB / RuDB max RSS |',
    '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for size in sizes:
    for fmt in ['native', 'parquet']:
        d, r = totals(size, 'duckdb-' + fmt), totals(size, 'rudb-' + fmt)
        lines.append(f"| {size} | {fmt} | {d['wall']:.3f} | {r['wall']:.3f} | {d['wall']/r['wall']:.2f}x | {d['cpu']:.3f} | {r['cpu']:.3f} | {d['rss']/2**20:.2f} | {r['rss']/2**20:.2f} | {d['rss']/r['rss']:.2f}x |")
lines += ['', 'Ratios above one favor RuDB. All totals cover the same 43 completed queries. A ratio of totals differs from a geometric mean of per-query ratios.', '',
    'The following table excludes Q1 through Q7 to show the remaining workload separately. It does not prove that every remaining query scans rows.', '',
    '| Sample | Format | DuckDB Q8 to Q43 wall total (s) | RuDB Q8 to Q43 wall total (s) | DuckDB / RuDB wall |',
    '| --- | --- | ---: | ---: | ---: |']
for size in sizes:
    for fmt in ['native', 'parquet']:
        d, r = totals(size, 'duckdb-' + fmt, 8), totals(size, 'rudb-' + fmt, 8)
        lines.append(f"| {size} | {fmt} | {d['wall']:.3f} | {r['wall']:.3f} | {d['wall']/r['wall']:.2f}x |")
lines += ['', '## Query-level target', '',
    '| Sample | Format | Wall-ratio geometric mean | Queries at least 10x faster / 43 | Queries with at least 10x lower peak RSS / 43 | Queries meeting both / 43 |',
    '| --- | --- | ---: | ---: | ---: | ---: |']
for size in sizes:
    for fmt in ['native', 'parquet']:
        ratios = [(groups[size,'duckdb-'+fmt,q]['wall']/groups[size,'rudb-'+fmt,q]['wall'], groups[size,'duckdb-'+fmt,q]['rss']/groups[size,'rudb-'+fmt,q]['rss']) for q in range(1,44)]
        lines.append(f"| {size} | {fmt} | {statistics.geometric_mean(t for t,m in ratios):.2f}x | {sum(t>=10 for t,m in ratios)} | {sum(m>=10 for t,m in ratios)} | {sum(t>=10 and m>=10 for t,m in ratios)} |")
lines += ['', 'These counts use per-query wall medians and the largest observed RSS in each engine. They measure performance, with answer differences qualified below.', '',
    '## Q1 through Q4 at 10m', '',
    '| Query | Format | DuckDB wall (ms) | RuDB wall (ms) | DuckDB / RuDB wall | DuckDB median RSS (MiB) | RuDB median RSS (MiB) |',
    '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for q in range(1,5):
    for fmt in ['native','parquet']:
        d,r=groups['10m','duckdb-'+fmt,q],groups['10m','rudb-'+fmt,q]
        lines.append(f"| Q{q} | {fmt} | {d['wall']*1000:.3f} | {r['wall']*1000:.3f} | {d['wall']/r['wall']:.2f}x | {d['median_rss']/2**20:.2f} | {r['median_rss']/2**20:.2f} |")
lines += ['', '## Native load cost', '',
    'Each load has one observation and includes building ordinary metadata and checkpointing. The 4GB engine setting is not a cap on whole-process RSS.', '',
    '| Sample | Engine | Load wall (s) | Load CPU (s) | Peak RSS (MiB) | Native file (MiB) |',
    '| --- | --- | ---: | ---: | ---: | ---: |']
for size in sizes:
    for engine in ['duckdb-native','rudb-native']:
        r=next(r for r in loads if (r['size'],r['engine'])==(size,engine))
        lines.append(f"| {size} | {engine} | {r['wall_s']:.3f} | {r['cpu_s']:.3f} | {r['peak_rss_bytes']/2**20:.2f} | {r['database_bytes']/2**20:.2f} |")
lines += ['', '## Answer checks', '',
    'All original outputs were checked across four cases and eight executions. Integers are exact, including values near 2^63; floating point uses a 1e-9 tolerance. Differing order and selections remain visible. Separate untimed retests add deterministic output-column tie breakers without replacing timed SQL or its original results.', '',
    '| Sample | Original match | Same rows, different order | Different selection, deterministic retest matches | Failed or unresolved |',
    '| --- | ---: | ---: | ---: | ---: |']
for size in sizes:
    counts=collections.Counter(c['result'] for c in checks if c['size']==size)
    lines.append(f"| {size} | {counts['original match']} | {counts['same rows; different order']} | {counts['original selections differ; deterministic retest match']} | {sum(n for k,n in counts.items() if k not in allowed)} |")
q29=next(c['result'] for c in checks if (c['size'],c['query'])==('10m',29))
lines += ['', f'Q29 at 10m: **{q29}**. Matching deterministic retests do not establish correctness of every originally selected row. This report does not claim all original outputs are identical.', '',
    '## Remaining gaps at 10m', '',
    'The slowest wall ratios identify where to profile next. Timing alone does not establish the cause.', '',
    '| Format | Query | DuckDB wall (ms) | RuDB wall (ms) | DuckDB / RuDB wall | DuckDB median RSS (MiB) | RuDB median RSS (MiB) |',
    '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for fmt in ['native','parquet']:
    ranked=sorted(range(1,44),key=lambda q:groups['10m','duckdb-'+fmt,q]['wall']/groups['10m','rudb-'+fmt,q]['wall'])
    for q in ranked[:7]:
        d,r=groups['10m','duckdb-'+fmt,q],groups['10m','rudb-'+fmt,q]
        lines.append(f"| {fmt} | Q{q} | {d['wall']*1000:.3f} | {r['wall']*1000:.3f} | {d['wall']/r['wall']:.2f}x | {d['median_rss']/2**20:.2f} | {r['median_rss']/2**20:.2f} |")
lines += ['', '## Reproduce and inspect', '',
    f'The [per-query tables]({asset}/per-query.md), [raw repetitions]({asset}/raw.jsonl.gz), [metadata]({asset}/metadata.json), [answer checks]({asset}/correctness.json), [native file hashes]({asset}/native-files.json), and [provenance]({asset}/provenance.json) retain the evidence. The [output archive]({asset}/outputs.tar.gz) contains every CSV, stderr and resource record, original SQL, deterministic diagnostic SQL, script snapshots, and the build log. Binaries and data files are excluded; their hashes and paths are recorded.', '',
    'Build clean main with `CARGO_INCREMENTAL=0 cargo build --release -p rudb-cli --bin rudb -j8`. The repository pins Rust 1.98.0 and compiles x86_64 for x86-64-v3. The benchmark helper uses `cc -O2 -std=c11 -Wall -Wextra -Werror`. Measurement and ordering tests passed on macOS and Linux, each with one platform-specific skip.', '',
    '```sh',
    'python3 scripts/clickbench-audit.py \\',
    '  --duckdb "$DUCKDB" --rudb "$RUDB" --data "$DATA" --output "$OUTPUT" \\',
    '  --sizes 1k 10k 1m 10m --hot 7 --threads 6 --memory-limit 4GB \\',
    '  --max-load 8 --idle-timeout 600 --timeout 180',
    'python3 scripts/verify-clickbench-audit.py "$OUTPUT"',
    '```', '',
    'Export the canonical benchmark SQL into a new output directory first. Reuse the recorded normalization projection for these raw integer date and time samples. No engine optimization was merged as part of this rerun.', '']
if meta['max_load'] is None:
    lines[2:2] = ['This is a contention diagnostic. The capacity-gated attempt stopped before completing the first sample because new workloads saturated the host. This separate rerun records all original SQL without a load gate. It must not replace the preceding quiet baseline or support a claimed commit speedup or achievement of the 10x target.', '']
    lines = [line if not line.startswith('The shared Linux Hyper-V host') else
        f'The shared Linux Hyper-V host exposes 32 logical CPUs on an Intel Core i9-13900K and about 31 GiB RAM. This diagnostic has no capacity gate or exclusive CPUs. Pre-child load ranged from {min(before):.2f} to {max(before):.2f}; post-child load ranged from {min(after):.2f} to {max(after):.2f}. Load, context switches, faults, CPU, stdout, and stderr are retained. Contention can affect engines differently, and measurements here do not establish an engine speedup.' for line in lines]
    lines = [line.replace('  --max-load 8 --idle-timeout 600 --timeout 180', '  --timeout 180') for line in lines]
    lines = [line.replace('These counts use per-query wall medians', 'These diagnostic counts do not establish the target under controlled conditions. They use per-query wall medians') for line in lines]
(out.parent / (asset + '.md')).write_text('\n'.join(lines))
provenance = dict(engine_source_commit='6a89e090e227ab62864ed26952ed5a84ae63a0f8',
    engine_source_archive_sha256='a73d9bdab22dcb8fc9c63788ca6e1efa2c183959e9105113d2d10e029a7797ee',
    benchmark_commit='6deab90337a16a2eba225bae4ad383063336d209',
    rebased_worktrees=dict(topology='d9d82143f4db1d202143c6c3f6f36a5ab779cc02',schema_index='41cb6f15d8e2d93628c03ad50f1d7735ffa2d788',bound_header='348a4978264454efad4ac3c8230349697dd6681f'),
    pending_patches_measured=False,
    build='CARGO_INCREMENTAL=0 cargo build --release -p rudb-cli --bin rudb -j8',
    rustc='rustc 1.98.0 (88d9e12ae 2026-08-18)',
    binary_hashes=meta['binaries'], artifacts={p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file() and p.name != 'provenance.json'})
(out / 'provenance.json').write_text(json.dumps(provenance, indent=2)+'\n')
print(json.dumps(dict(queries=len(queries),loads=len(loads),checks=collections.Counter(c['result'] for c in checks),load_before=[min(before),max(before)],load_after=[min(after),max(after)]), indent=2))
