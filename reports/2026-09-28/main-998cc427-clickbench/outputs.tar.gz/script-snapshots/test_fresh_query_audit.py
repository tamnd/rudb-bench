"""Check positional and pairwise balance in fresh-process comparisons."""
import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('fresh', Path(__file__).with_name('fresh-query-audit.py'))
fresh = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fresh)


class OrderingTests(unittest.TestCase):
    def test_every_case_occupies_every_position_equally(self):
        for count in [2, 3, 4, 6]:
            cases = list(range(count))
            orders = [fresh.run_order(cases, run) for run in range(2*count)]
            for case in cases:
                self.assertEqual([sum(order[position] == case for order in orders)
                                  for position in range(count)], [2]*count)

    def test_each_pair_runs_first_equally_often(self):
        for count in [2, 3, 4, 6]:
            cases = list(range(count))
            orders = [fresh.run_order(cases, run) for run in range(2*count)]
            for left in cases:
                for right in cases[left+1:]:
                    self.assertEqual(sum(order.index(left) < order.index(right) for order in orders), count)


if __name__ == '__main__':
    unittest.main()
