import json
import os
from pathlib import Path
import subprocess

base = Path('/home/gopher/rudb-bound-header-2026-09-28')
root = base / 'results/schema-c383-callgrind'
root.mkdir(exist_ok=False)
records = []
for size in ['1k', '10k', '1m', '10m']:
    cases = json.loads((base / 'results' / f'schema-c383-q1-{size}-cases.json').read_text())
    for case in cases:
        if not case['name'].endswith('parquet'):
            continue
        prefix = root / f'{size}-{case["name"]}'
        command = ['valgrind', '--tool=callgrind', '--cache-sim=no', '--branch-sim=no',
                   '--callgrind-out-file=' + str(prefix) + '.callgrind', *case['command']]
        with prefix.with_suffix('.stdout').open('wb') as out, prefix.with_suffix('.stderr').open('wb') as err:
            result = subprocess.run(command, stdout=out, stderr=err,
                                    env={**os.environ, 'LC_ALL':'C', 'TZ':'UTC', 'RUDB_PARQUET_MIRROR':'0'})
        assert result.returncode == 0, (size, case['name'], result.returncode)
        assert prefix.with_suffix('.stdout').read_text() == case['expected']
        data = Path(str(prefix) + '.callgrind').read_text()
        instructions = int(next(line.split()[1] for line in data.splitlines() if line.startswith('summary:')))
        record = dict(size=size, case=case['name'], instructions=instructions, command=command,
                      expected=case['expected'], status='ok')
        records.append(record)
        (root / 'summary.json').write_text(json.dumps(records, indent=2) + '\n')
        print(size, case['name'], instructions, flush=True)
